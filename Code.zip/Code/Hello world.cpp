#include <algorithm>
#include <iostream>
using namespace std;

int main()
{
    int a, b, c[10];
    cin >> a >> b;
    cout << a+b;
}