## 前言

某：这道题用到了 ```double``` ... ...(还没说完)

MarchKid_Joe：卡精度吗？

---

## 多项式运算

### 多项式加法

给定多项式 $f(x),g(x)$：

$$
f(x)=\displaystyle\sum_{i=0}^{n}a_i x^i
$$

$$
g(x)=\displaystyle\sum_{i=0}^{m}b_i x^i
$$

则得到 $f(x)+g(x)$。

$$
f(x)+g(x)=\displaystyle\sum_{i=0}^{\max(n,m)}(a_i+b_i) x^i
$$

### 多项式乘法

给定多项式 $f(x),g(x)$：

$$
f(x)=\displaystyle\sum_{i=0}^{n}a_i x^i
$$

$$
g(x)=\displaystyle\sum_{i=0}^{m}b_i x^i
$$

则得到 $f(x)+g(x)$。

$$
f(x)*g(x)=\displaystyle\sum_{i=0}^{m+n}\displaystyle\sum_{j=0}^{i}(a_j*b_{i-j}) x^i
$$

### 多项式整除

存在 $f(x)=h(x)*Q(x)$。

### 多项式取模

对 $x$ 的次幂取模：

$$
F(x)=f(x)(\bmod\,x^a)
$$

逆元

$$
f(x)*g(x)\equiv 1\qquad(\bmod\,x^a)
$$

我们规定 $f$ 为 $x$ 的次幂小于 $a$ 的部分，令 $s_i$ 为第 $i$ 项的系数，即：

$$
F(x)=\displaystyle\sum_{i=0}^{a-1}s_ix^{i}
$$

对多项式取模:

$$
g(x)=f(x)(\bmod\,h(x))
$$

即 $f(x)=g(x)+h(x)*Q(x)$。

逆元

$$
f(x)*g(x)\equiv 1\qquad(\bmod\,h(x))
$$

## 拉格朗日插值

1. 引入

    给定 $n$ 个点 $(x_i,y_i)$ 确定一个多项式 $f(x)$，求 $f(k)$。

2. 结论

    $$
    \begin{aligned}
    f(k)=\displaystyle\sum_{i=1}^{n}y_i\displaystyle\prod_{j=1\land j\not= i}^{n}\frac{(k-x_i)}{(x_i-x_j)}
    \end{aligned}
    $$

3. 证明

    首先，我们可以得到：

    $$
    f(x)-f(a)={s_0}(x^0-a^0)+s_1(x^1-a^1)+...+s_n(x^n-a^n)
    $$

    可以发现，这几项肯定含有 $(x-a)$ 这项。

    设：

    $$
    f(x)\equiv f(a)
    \qquad
    (\bmod(x-a))
    $$

    根据这个式子列出同余方程：

    $$
    \begin{cases}
    f(x)&\equiv y_1(\bmod(x-x_1))\\
    f(x)&\equiv y_2(\bmod(x-x_2))\\
    &\vdots\\
    f(x)&\equiv y_n(\bmod(x-x_n))\\
    \end{cases}
    $$

    然后套上~~多项式~~**中国剩余定理**(CRT)。

    设

    $$
    M=\displaystyle\prod_{i=1}^{n}(x-x_i)
    $$

    $$
    m_i=\displaystyle\prod_{j=1\land i\not=j}^{n}(x-x_j)
    $$

    则 $m_i$ 在模 $(x-x_i)$ 意义下的逆元为：

    $$
    m_i^{-1}=\displaystyle\prod_{j=1\land j\not=i}^{n}\frac{1}{(x_i-x_j)}
    $$

    最后合并得到

    $$
    \begin{aligned}
    f(x)
    &=\displaystyle\sum_{i=1}^{n}y_i m_i m_i^{-1}\\
    &=\displaystyle\sum_{i=1}^{n}y_i \displaystyle\prod_{j=1\land j\not=i}^{n}\frac{(x-x_i)}{(x_i-x_j)}\\
    \end{aligned}
    $$

    问题是让求 $f(k)$ 对应的值，将 $k$ 带入可得，时间复杂度 $O(n^2)$。

4. Code

    ```cpp
    #include <bits/stdc++.h>
    #define SIZE (2000 + 10)
    #define MOD (998244353)
    #define ll long long
    using namespace std;
    int x[SIZE];
    int y[SIZE];
    ll quick_pow(ll x, ll y)
    {
        ll ans = 1;
        while (y > 0)
        {
            if (y & 1)
                ans = ans * x % MOD;
            x = x * x % MOD;
            y >>= 1;
        }
        return ans;
    }
    ll inv(ll m)
    {
        return quick_pow(m, MOD - 2);
    }
    int main()
    {
        int n, k;
        scanf("%d%d", &n, &k);
        for (int i = 1; i <= n; i++)
            scanf("%d%d", &x[i], &y[i]);
        ll f = 0;
        for (int i = 1; i <= n; i++)
        {
            ll s = 1;
            for (int j = 1; j <= n; j++)
                if (i != j)
                {
                    s *= ((k - x[j] + MOD) % MOD * inv(x[i] - x[j] + MOD) % MOD);
                    s %= MOD;
                }
            f += (y[i] * s % MOD);
            f %= MOD;
        }
        printf("%lld", f);
        return 0;
    }
    ```

5. [【模板】拉格朗日插值](https://www.luogu.com.cn/problem/P4781)

**实用技巧**：**常量**（const typename mod = ? 或者是 define mod = ?） 比**变量**（直接赋值）取模的速度**快得多**。

## 单位根

### 单位根

1. 定义

    单位根，一般写为 $\omega$，定义为在复数意义下的 $x^n=1$ 的解是 $n$ 次复根。这样的解有 $n$ 个，称这 $n$ 个解都是 $n$ 次**单位根**，又称**单位复根**。$n$ 次单位根把单位圆 $n$ 等分。

    如图，$x^8=1$ 的 $8$ 次单位根。记作 $w_8^i$。

![](https://cdn.luogu.com.cn/upload/image_hosting/x0x4v9tb.png)

2. 性质

    $(1)$.$w_{n}^{n}=1$

    $(2)$.$w_{2n}^{2k}=w_{n}^{k}$

    其实可以感性理解为分数通分。

    $(3)$.$w_{2n}^{n+k}=-w_{2n}^{k}$

    就相当于在单位圆上转了半圈，符号取反。

当已经了解了这些性质后，FFT 基本就可以开始了。

### 单位根反演

1. 结论

    $$
    \boxed
    {
    \frac{1}{n}\displaystyle\sum_{i=0}^{n-1}w_{n}^{ik}=[n|k]
    }
    $$

2. 证明

    对于 $[n\mid k]$：

    $$
    \because
    w_{n}^{ik}=w^{0}=1
    $$

    $$
    \therefore
    \frac{1}{n}\displaystyle\sum_{i=0}^{n-1}w_{n}^{ik}=\frac{1}{n}\times n=1
    $$

    对于 $[n\nmid k]$：

    通过等比数列公式得知：

    $$
    \displaystyle\sum_{i=0}^{n-1}w_{n}^{ik}=w^0 \frac{1-w_n^{nk}}{1-w_n^{k}}
    $$

    所以得出：

    $$
    \begin{aligned}
    \because
    &w^0=1\land w_{n}^{nk}=1\\
    \therefore
    &w_{n}^{nk}=0\\
    \therefore
    &\frac{1}{n}\displaystyle\sum_{i=0}^{n-1}w_{n}^{ik}=0
    \end{aligned}
    $$

## 快速傅里叶变换(Fast Fourier Transform,FFT)

### 介绍

快速傅里叶变换(Fast Fourier Transform)，快速求多项式乘积，主要思想是先将**系数转化为点数再转化为系数**求解。

### 复数(complex)

c++ STL 中有复数的库，但是常数太大，一般手写，毕竟复数的运算也不多。

模板Code

```cpp
struct complex
{
    double x, y;
    complex(double x = 0, double y = 0) : x(x), y(y)
    {
    }
    friend complex operator-(const complex &A, const complex &B)
    {
        return complex(A.x - B.x, A.y - B.y);
    }
    friend complex operator+(const complex &A, const complex &B)
    {
        return complex(A.x + B.x, A.y + B.y);
    }
    friend complex operator*(const complex &A, const complex &B)
    {
        return complex(A.x * B.x - A.y * B.y, A.x * B.y + A.y * B.x);
    }
};
```

### DFT

1. DFT 简介

    DFT 是将多项式系数转为点数的过程，给定一个**系数表示法**的多项式 $F(x)$，设其**点数表示法**的多项式为 $G(x)$。

2. 转化

    $$
    G(k)=\displaystyle\sum_{i=0}^{n-1}{w_{n}^{ik}F(i)}
    $$

3. 证明及求解过程

    根据转化的式子，但暴力求肯定不行（暴力还不如用高精度乘法），考虑将 $F(x)$ 拆开，我们按奇偶将 $F(x)$ 分为两部分，假设 $F(x)$ 为 $3$ 次多项式：

    $$
    F(x)=(a_0x^0+a_2x^2)+(a_1x^1+a_3x^3)
    $$

    定义 $F_1(x^2),F_2(x^2)$：

    $$
    F_2(x^2)=(a_0x^0+a_2x^2)
    $$

    $$
    F_1(x^2)=(a_1x^0+a_3x^2)
    $$

    于是就得到:

    $$
    F(x)=F_2(x^2)+xF_1(x^2)
    $$

    将 $x=w_{n}^{k}$ 带入得到:

    $$
    F(w_{n}^{k})=F_2(w_{n}^{2k})+w_{n}^{k}F_1(w_{n}^{2k})
    $$

    将 $x=w_{n}^{k+\frac{n}{2}}$ 带入得到:

    $$
    F(w_{n}^{k+\frac{n}{2}})=F_2(w_{n}^{2k+n})+w_{n}^{k+\frac{n}{2}}F_1(w_{n}^{2k+n})
    $$

    $$
    F(w_{n}^{k+\frac{n}{2}})=F_2(w_{n}^{2k})-w_{n}^{k}F_1(w_{n}^{2k})
    $$

    我们发现，$x=w_{n}^{k}$ 与 $x=w_{n}^{k+\frac{n}{2}}$ 的结果只差一个正负号 $\pm$。于是我们在处理 $x=w_{n}^{k}$ 时可以处理出另一半 $x=w_{n}^{k+\frac{n}{2}}$ 的情况，二分递归求解。

    当然为了分的均匀，我们一般把 $n$ 初始化为**2的整次幂**，对于多出来的部分，由于多出来的部分系数是 $0$，**两个多项式**计算时没有影响(**Warning:多个计算时不清除多余的部分会有影响**)，时间复杂度 $O(n\log n)$。

### IDFT

嗯。算多项式乘法要让人看懂的话总得用系数表示吧。

1. IDFT 简介

    出题人会让你计算出多项式的系数，肯定不会让你输出点数吧。考虑将多项式**点数表示法变为系数表示法**。

2. 结论

    $$
    F(k)=\frac{1}{n}\displaystyle\sum_{i=0}^{n-1}{w_{n}^{-ik}G(i)}
    $$

3. 证明

    可能大家发现，跟 DFT 的转化式差不多。具体证明用到**单位根反演**。

    $$
    \begin{aligned}
    F(k)
    &=\frac{1}{n}\displaystyle\sum_{i=0}^{n-1}{w_{n}^{-ik}G(i)}\\
    &=\frac{1}{n}\displaystyle\sum_{i=0}^{n-1}{w_{n}^{-ik}\displaystyle\sum_{j=0}^{n-1}{w_{n}^{ij}F(j)}}\\
    &=\frac{1}{n}\displaystyle\sum_{i=0}^{n-1}\displaystyle\sum_{j=0}^{n-1}{w_{n}^{i(j-k)}F(j)}
    \end{aligned}
    $$

    推到这里又要分情况：

    $(1)$.$j=k$

    $$
    \begin{aligned}
    F(k)
    &=\frac{1}{n}\displaystyle\sum_{i=0}^{n-1}{w^{0}F(k)}\\
    &=\frac{nF(k)}{n}\\
    &=F(k)\\
    \end{aligned}
    $$

    $(2)$.$j\not=k$

    $$
    \begin{aligned}
    F(k)
    &=\frac{1}{n}\displaystyle\sum_{i=0}^{n-1}{w_{n}^{i(j-k)}F(j)}\\
    \end{aligned}
    $$

    根据等比数列公式得到：

    $$
    \displaystyle\sum_{i=0}^{n-1}w_{n}^{i(j-k)}=w^0\frac{1-w_{n}^{(j-k)n}}{1-w_n^{j-k}}=0
    $$

    证毕。

### 二进制翻转

~~递归太慢了~~，考虑如何非递归。

见下图，用非递归模拟递归过程，用到了二进制反转。

![](https://cdn.luogu.com.cn/upload/image_hosting/8xx0qdh3.png)

发现最终的数组编号就是原数组编号二进制反过来。

成功了！

对数组 A 进行二进制反转代码如下：

Code

```cpp
void bin(Type *A, int len)
{
    for (int i = 1, j = len >> 1; i < len - 1; i++)
    {
        if (i < j)
            swap(A[i], A[j]);
        int k = len >> 1;
        while (j >= k)
        {
            j -= k;
            k >>= 1;
        }
        j |= k;
    }
}
```

### FFT总结

1. 注意

    $n$ 要初始为 $2$ 的整次幂。

    IDFT 与 DFT 只是 $w$ 符号相反。

    IDFT 记得除以 $n$。

    初始化：

    $$
    \begin{aligned}
    &w_{n}^{1}=(\cos{\frac{2\pi}{n}},\sin{\frac{2\pi}{n}})\\
    &w^0=(1,0)\\
    &w_{n}^{-1}=(\cos{\frac{2\pi}{n}},-\sin{\frac{2\pi}{n}})\\
    \end{aligned}
    $$

2. Code

   ```cpp
    #include <bits/stdc++.h>
    #define SIZE (4000000 + 10)
    #define double long double
    using namespace std;
    const double pi = acos(-1.0);
    struct Complex
    {
        double x, y;
        Complex(double x = 0, double y = 0) : x(x), y(y)
        {
        }
        friend Complex operator-(const Complex &A, const Complex &B)
        {
            return Complex(A.x - B.x, A.y - B.y);
        }
        friend Complex operator+(const Complex &A, const Complex &B)
        {
            return Complex(A.x + B.x, A.y + B.y);
        }
        friend Complex operator*(const Complex &A, const Complex &B)
        {
            return Complex(A.x * B.x - A.y * B.y, A.x * B.y + A.y * B.x);
        }
    };
    Complex F[SIZE], G[SIZE], ANS[SIZE];
    void bin(Complex *A, int len)
    {
        for (int i = 1, j = len >> 1; i < len - 1; i++)
        {
            if (i < j)
                swap(A[i], A[j]);
            int k = len >> 1;
            while (j >= k)
            {
                j -= k;
                k >>= 1;
            }
            j |= k;
        }
    }
    void FFT(Complex *A, int len, int opt)
    {
        bin(A, len);
        for (int i = 1; i < len; i <<= 1)
        {
            Complex wn = Complex(cos(2 * pi / (i << 1)), opt * sin(2 * pi / (i << 1)));
            for (int j = 0; j < len; j += (i << 1))
            {
                Complex w = Complex(1, 0);
                for (int k = j; k < j + i; k++, w = w * wn)
                {
                    Complex x = A[k];
                    Complex y = w * A[k + i];
                    A[k] = x + y;
                    A[k + i] = x - y;
                }
            }
        }
    }
    void __FFT(Complex *A, int len, int opt)
    {
        if (len == 1)
            return;
        Complex a1[len >> 1], a2[len >> 1];
        for (int i = 0; i < (len >> 1); i++)
        {
            a1[i] = A[i << 1];
            a2[i] = A[i << 1 | 1];
        }
        __FFT(a1, len >> 1, opt);
        __FFT(a2, len >> 1, opt);
        Complex w = Complex(1, 0);
        Complex wn = Complex(cos(2 * pi / len), opt * sin(2 * pi / len));
        for (int i = 0; i < (len >> 1); i++, w = w * wn)
        {
            Complex x = w * a2[i];
            A[i] = a1[i] + x;
            A[i + (len >> 1)] = a1[i] - x;
        }
    }
    int main()
    {
        int n, m, len = 1;
        scanf("%d%d", &n, &m);
        for (int i = 0, k; i <= n; i++)
        {
            scanf("%d", &k);
            F[i].x = k;
        }
        for (int i = 0, k; i <= m; i++)
        {
            scanf("%d", &k);
            G[i].x = k;
        }
        while (len <= (n + m))
            len <<= 1;
        FFT(F, len, 1);
        FFT(G, len, 1);
        for (int i = 0; i <= len; i++)
            ANS[i] = F[i] * G[i];
        FFT(ANS, len, -1);
        for (int i = 0; i <= n + m; i++)
            printf("%d ", (int)((ANS[i].x + 1.0 /*误差*/) / len));
        return 0;
    }
   ```

3. [【模板】多项式乘法](https://www.luogu.com.cn/problem/P3803)

**友情提醒**：根据前言自己品。

## 快速数论变换(Number-theoretic transform, NTT）

### （真）简介

根据**原根**某些（MarchKid_Joe表示不清楚）奇妙的性质，原根可以与单位根相互转化。

### 算法

只需要将 $w_n$ 改为 $g^{\frac{p-1}{n}}​$，然后 NTT 就没了。

有一条限制，模数 $p=a\times2^b+1$，一般都会用 $998244353$，原根为 $3$，模 $998244353$ 意义下逆元为 $332748118$。

至于求取原根，可以参考[数论【难】-原根](http://marchkidjoe.mygamesonline.org/math-hard)。

给出一部分质数和原根表（摘自[zh_dou](https://www.cnblogs.com/zh-dou/p/About-Polynomial.html)）

![](http://marchkidjoe.mygamesonline.org/wp-content/uploads/2022/08/fftntt01.png)

### 代码实现

只需要对 FFT 进行小改就变为 NTT 了。对于 $g^{\frac{p-1}{n}}$ 逆过来不是 $-g^{\frac{p-1}{n}}$，而是 $g^{-\frac{p-1}{n}}$，其实就是取倒数或者说求逆元的 $\frac{p-1}{n}$ 次方。

这里只给 NTT 代码，记得逆回系数时要乘以 $\frac{1}{n}$，当然是 $\frac{1}{n}$ 模 $p$ 意义下的逆元，其他的不变。

Code

```cpp
const long long MOD = 998244353;
const long long g = 3;
const long long ginv = 332748118;
void NTT(long long *A, int len, int opt)
{
    bin(A, len);
    for (int i = 1; i < len; i <<= 1)
    {
        long long wn = quick_pow(opt == 1 ? g : ginv, (MOD - 1) / (i << 1));
        for (int j = 0; j < len; j += (i << 1))
        {
            long long w = 1;
            for (int k = j; k < j + i; k++, w = w * wn % MOD)
            {
                long long x = A[k] % MOD;
                long long y = w * A[k + i] % MOD;
                A[k] = (x + y) % MOD;
                A[k + i] = ((x - y) + MOD) % MOD;
            }
        }
    }
}
void __NTT(long long *A, int len, int opt)
{
    if (len == 1)
        return;
    long long a1[len >> 1], a2[len >> 1];
    for (int i = 0; i < (len >> 1); i++)
    {
        a1[i] = A[i << 1];
        a2[i] = A[i << 1 | 1];
    }
    __NTT(a1, len >> 1, opt);
    __NTT(a2, len >> 1, opt);
    long long w = 1;
    long long wn = quick_pow(opt == 1 ? g : ginv, (MOD - 1) / len);
    for (int i = 0; i < (len >> 1); i++, w = w * wn % MOD)
    {
        long long x = w * a2[i] % MOD;
        A[i] = (a1[i] + x) % MOD;
        A[i + (len >> 1)] = ((a1[i] - x) + MOD) % MOD;
    }
}
```