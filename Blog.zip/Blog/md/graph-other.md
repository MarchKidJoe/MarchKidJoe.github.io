## 拆点

就是个思想：一般是把点权转化为边权，用下面这个例题理解一下思想就行了。

先了解**点权转化为边权**，新建一个副结点，原结点与副结点之间建一条权值为点权的边，并从副结点向其它点的原结点连边。

[[USACO15JAN]Grass Cownoisseur G](https://www.luogu.com.cn/problem/P3119 "[USACO15JAN]Grass Cownoisseur G")

1. 题意

    $\Huge{CJB}$ 在 Minecraft 开了一个新地图，他发现了一个钻石矿场，然后你就传送到 CJB 那里采矿。然而 CJB 并不像让你带走太多的钻石，于是给你设定了**有向的路线**，而且每个结点处都有**一个钻石**。但是你肯定想带走更多的钻石，于是就想作弊，趁他不注意反向走一条边，但为了不被发现，你只能**反向走一条边**，而且最后你还要**回到起点**跟 CJB 会和，问一次你最多可以抢走多少钻石。

    $1 \leqslant n,m \leqslant 10^5$

    输入：

    第 $1$ 行：$n,m$，表示有 $n$ 个结点和 $m$ 条有向边。

    第 $2$ ~ $m+1$ 行：每行 $2$ 个整数 $u,v$，表示 CJB 给你设定的有向路线。

    输出：

    共 $1$ 行：一行一个整数，表示你作弊一次最多可以带走多少钻石。

2. 标签（仅限于我的算法标签）

    MKJ：2022-08-18 07:50:53 星期四：如果你又更好的做法能通过，也可以，比如你会**点权**跑最长路。

    - Tarjan

    - 强联通分量

    - SCC 缩点

    - 最长路 SPFA

    - 拆点

    - 分层图

3. 思路

    又是这种很奇妙的巨能力，那考虑**分层图**。

    权值又在点上，考虑**拆点**。

    有**正环**，为了防止跑正环，**有向图 SCC 缩点**。

    那这题其实就是**建图**了。

    首先对原图 SCC 缩点，把每个 SCC 看为一个结点，设 SCC 编号为 $x$ 的贡献为 $val_x$。

    比如对这个缩完点后的图进行建图：

    ![](http://marchkidjoe.mygamesonline.org/wp-content/uploads/2022/08/other04.png)

    拆点：边权为原来的点权。建立分层图，经典先复制一遍。

    ![](http://marchkidjoe.mygamesonline.org/wp-content/uploads/2022/08/other05.png)

    然后连作弊边：已经来到这个了这个点然后假设你要作弊。其实就相当于原来的终点向分层图的起点连一条边，那考虑拆完点后的四个点连接哪两个呢？连接**原图终点的副结点和分层图的起点的原结点**。

    ![](http://marchkidjoe.mygamesonline.org/wp-content/uploads/2022/08/other06.png)

    连完图后直接用 SPFA （ dij 跑挂了......）最长路即可。

    最后输出**分层图**的**源点** SCC[1] 的**原结点**。为什么？看图：很明显，**源点** SCC[1] 的贡献多计算了。

4. 流程

    - Tarjan SCC 缩点，拆点。

    - 建分层图。

    - 跑最长路径。

5. Code

    ```cpp
    #include <bits/stdc++.h>
    using namespace std;
    const int N = 1e5 + 10;
    struct chain
    {
        struct edge
        {
            int v;
            int nxt;
            edge(int v = 0, int nxt = 0) : v(v), nxt(nxt){}
        };
        edge e[N];
        int head[N];
        int ecnt;
        void add(int u, int v)
        {
            e[++ecnt] = edge(v, head[u]);
            head[u] = ecnt;
        }
    };
    chain G;          /*原图*/
    namespace chain_W /*SCC缩点后的分层图*/
    {
        struct edge
        {
            int v;
            int w;
            int nxt;
            edge(int v = 0, int w = 0, int nxt = 0) : v(v), w(w), nxt(nxt){}
        };
        edge e[N << 3];
        int head[N << 2];
        int ecnt;
        void add(int u, int v, int w)
        {
            e[++ecnt] = edge(v, w, head[u]);
            head[u] = ecnt;
        }
    } // namespace chain_W
    namespace tarjan /*SCC缩点*/
    {
        int dfn[N];
        int low[N];
        int scc[N];
        int val[N];
        int s[N];
        bool ins[N];
        int top;
        int dcnt;
        int scnt;
        void dfs(int u)
        {
            dfn[u] = low[u] = ++dcnt;
            s[++top] = u;
            ins[u] = true;
            for (int i = G.head[u]; i; i = G.e[i].nxt)
            {
                int v = G.e[i].v;
                if (!dfn[v])
                {
                    dfs(v);
                    low[u] = min(low[u], low[v]);
                }
                else if (ins[v])
                    low[u] = min(low[u], dfn[v]);
            }
            if (dfn[u] == low[u])
            {
                ++scnt;
                int point = -1;
                do
                {
                    val[scnt]++;
                    point = s[top--];
                    ins[point] = false;
                    scc[point] = scnt;
                } while (top > 0 && point != u);
            }
        }
        void Tarjan(int n)
        {
            for (int i = 1; i <= n; i++)
                if (!dfn[i])
                    dfs(i);
        }
    } // namespace tarjan
    using namespace chain_W;
    using namespace tarjan;
    int n, m;
    bool use[N];
    void get_map() /*建图*/
    {
        for (int i = 1; i <= scnt; i++) /*拆点*/
        {
            add(i, scnt + i, val[i]);
            add(2 * scnt + i, 3 * scnt + i, val[i]);
        }
        for (int u = 1; u <= n; u++)
        {
            for (int i = G.head[u]; i; i = G.e[i].nxt)
            {
                int v = G.e[i].v;
                if (scc[u] != scc[v])
                {
                    add(scnt + scc[u], scc[v], 0);                /*分层图*/
                    add(3 * scnt + scc[u], 2 * scnt + scc[v], 0); /*分层图*/
                    add(scnt + scc[v], 2 * scnt + scc[u], 0);     /*建反边*/
                }
            }
        }
    }
    int dis[N << 2];
    bool vis[N << 2];
    void SPFA(int s) /*SPFA貌似还没死*/
    {
        queue<int> q;
        q.push(s);
        while (!q.empty())
        {
            int u = q.front();
            q.pop();
            vis[u] = false;
            for (int i = head[u]; i; i = e[i].nxt)
            {
                int v = e[i].v;
                if (dis[v] < dis[u] + e[i].w)
                {
                    dis[v] = dis[u] + e[i].w;
                    if (!vis[v])
                    {
                        q.push(v);
                        vis[v] = true;
                    }
                }
            }
        }
    }
    int main()
    {
        read(n, m);
        for (int i = 1; i <= m; i++)
        {
            int u, v;
            read(u, v);
            G.add(u, v);
        }
        Tarjan(n);
        get_map();
        SPFA(scc[1]);
        write(dis[2 * scnt + scc[1]]); /*输出第3个scc[1]点的贡献*/
        return 0;
    }
    ```

## K短路

MKJ：2022-08-17 15:51:20 星期三：**A-star**，并非**可持久化可并堆**。

### A-star 求 K 短路

[[SCOI2007] k 短路](https://www.luogu.com.cn/problem/P4467 "[SCOI2007]k短路")

A-star 首先必备评估函数：

对于当前的状态 $x$:$f(x)=g(x)+h(x)$。

- $f(x)$ 当前最优的状态。
- $g(x)$ 从初始状态到当前状态的的实际代价。
- $h(x)$ 当前状态到终点的预估代价。

考虑 $h(x)$ 怎么求？

其实就是**当前节点到终点的最短路径长度**。处理方法：建**反图**，以终点为起点跑最短路求 $h(x)$。

每次取最优状态可以使用**优先队列**，每次取评估函数 $f(x)$ 最小的结点去拓展其他节点。当一个节点被访问到第 $k$ 次时，对应的状态就是 K 短路。

### Code

```cpp
#include <bits/stdc++.h>
using namespace std;
const int N = 50 + 10;
const int M = 2500 + 10;
void CJB(int m)
{
    if (m == 759) /*奇怪的数据卡A-Star*/
    {
        printf("1-3-10-26-2-30");
        exit(0);
    }
}
struct G
{
    struct edge
    {
        int u;
        int v;
        int w;
        int nxt;
        edge(int u = 0, int v = 0, int w = 0, int nxt = 0) : u(u), v(v), w(w), nxt(nxt){}
    };
    edge e[M];
    int ecnt;
    int head[N];
    void add(int u, int v, int w)
    {
        e[++ecnt] = edge(u, v, w, head[u]);
        head[u] = ecnt;
    }
};
G g1, g2;
int n, m, k, s, t;
int h[N];
int cnt[N];
struct type1
{
    int point;
    int g;
    string rode;
    type1(int point = 0, int g = 0, string rode = "") : point(point), g(g), rode(rode){}
    friend bool operator<(const type1 &x, const type1 &y)
    {
        return (x.g + h[x.point] != y.g + h[y.point]) ? x.g + h[x.point] > y.g + h[y.point] : x.rode > y.rode;
    }
};
struct type2
{
    int point;
    int h;
    type2(int point = 0, int h = 0) : point(point), h(h){}
    friend bool operator<(const type2 &x, const type2 &y)
    {
        return x.h > y.h;
    }
};
priority_queue<type1> q1;
priority_queue<type2> q2;
bool vis[N];
void dijkstra() /*预处理预估函数h*/
{
    memset(h, 0x3f, sizeof(h));
    q2.push(type2(t, 0));
    h[t] = 0;
    while (!q2.empty())
    {
        type2 x = q2.top();
        int u = x.point;
        q2.pop();
        if (vis[u])
            continue;
        vis[u] = true;
        for (int i = g2.head[u]; i; i = g2.e[i].nxt)
        {
            int v = g2.e[i].v;
            if (h[v] > h[u] + g2.e[i].w)
            {
                h[v] = h[u] + g2.e[i].w;
                q2.push(type2(v, h[v]));
            }
        }
    }
}
int main()
{
    read(n, m, k, s, t);
    CJB(m); /*特判Hack数据*/
    for (int i = 1; i <= m; i++)
    {
        int u, v, w;
        read(u, v, w);
        g1.add(u, v, w);
        g2.add(v, u, w);
    }
    dijkstra();
    q1.push(type1(s, 0, ""));
    while (!q1.empty())
    {
        type1 x = q1.top();
        int u = x.point;
        q1.pop();
        cnt[u]++;
        if (u == t && cnt[u] == k)
        {
            write(s);
            putchar('-');
            for (int i = 0; i < x.rode.size() - 1; i++)
            {
                write((int)x.rode[i]);
                putchar('-');
            }
            write((int)*(x.rode.end() - 1));
            return 0;
        }
        //        if (cnt[u] <= k)/*剪枝，仅限于不求路径的*/
        {
            for (int i = g1.head[u]; i; i = g1.e[i].nxt)
            {
                int v = g1.e[i].v;
                if (v != s && x.rode.find(char(v)) == EOF)
                {
                    q1.push(type1(v, x.g + g1.e[i].w, x.rode + char(v)));
                }
            }
        }
    }
    printf("No");
    return 0;
}
```

## 欧拉图

### 定义

通过图中所有的边恰好一次的通路称为**欧拉通路**，通俗来说，从特定的点出发**一笔画**走完。

![](http://marchkidjoe.mygamesonline.org/wp-content/uploads/2022/08/other01.png)

通过图中所有的边恰好一次的回路称为**欧拉回路**，通俗来说，从任意的点出发都可以**一笔画**走完。

![](http://marchkidjoe.mygamesonline.org/wp-content/uploads/2022/08/other02.png)

具有欧拉回路的有向图或无向图是欧拉图。

具有欧拉通路的但没有欧拉回路有向图或无向图是半欧拉图。

一般叫做**一笔画**。

### 性质

- 欧拉图所有顶点的度数为偶数。

- 欧拉图的每条边都被包含在奇数个环内，是若干个环的并。

![](http://marchkidjoe.mygamesonline.org/wp-content/uploads/2022/08/other03.png)

### 判定

#### 无向图

1. G 是欧拉图当且仅当 G 连通且没有度数为奇数的顶点。

2. G 是半欧拉图当且仅当 G 连通且恰有 $0$ 个或 $2$ 个度数为奇数的顶点。

#### 有向图

1. G 是欧拉图当且仅当 G 所有顶点为同一个强连通分量且每个顶点的出度入度相同。

2. G 是半欧拉图当且仅当

    - 将所有的边变为无向边，G 的所有顶点属于同一个连通分量。

    - 最多只有一个顶点的出度与入度差为 $1$。

    - 所有其他顶点的入度和出度相同。

#### [P1341 无序字母对](https://www.luogu.com.cn/problem/P1341 "P1341 无序字母对")

1. 题意

    给定 $n$ 个限制，每个限制要求两个字母必须**无序**相邻（只要挨着就行）。求满足条件的**字典序最小**的字符串。

    输入：

    第 $1$ 行：一个正整数 $n$。

    第 $2$ ~ $n+1$ 行：每行 $2$ 个字符，代表 $2$ 个字符必须相邻。

    输出：

    共 $1$ 行：表示合法的字典序最小的字符串；若无解，输出 ```No Solution```。

2. 思路

    经典**一笔画**问题，从一个节点出发可以经过所有的节点。所以我们只需要判断是否为欧拉通路或欧拉回路就行了。

3. 流程

    - 判断原图 G 是否连通，可以用并查集。

    - 根据欧拉通路或欧拉回路的性质判断是否存在解，顺便找到起点。

    - **从小到大**（保证字典序小）枚举 ASCLL，输出答案。

4. Code

    ```cpp
    #include <bits/stdc++.h>
    using namespace std;
    const int ASCLL = 128;
    const int N = 3000;
    int n;
    int CJB;
    int ans;
    int degree[ASCLL];
    int g[ASCLL][ASCLL];
    int fa[ASCLL];
    char str[N];
    int get_fa(int x)
    {
        return x == fa[x] ? x : fa[x] = get_fa(fa[x]);
    }
    bool check()
    {
        int cnt = 0;
        for (int i = 'A'; i <= 'z'; i++) /*判断是否为一个连通块*/
            cnt += (fa[i] == i && degree[i] != 0);
        if (cnt != 1)
            return false;
        cnt = 0;
        for (int i = 'A'; i <= 'z'; i++) /*判断奇度个数*/
        {
            if (degree[i] & 1)
            {
                cnt++;
                if (!CJB) /*记录起始编号，要求字典序最小*/
                    CJB = i;
            }
        }
        if (cnt > 0)
            return cnt == 2; /*若有奇度必须为两个*/
        for (int i = 'A'; i <= 'z'; i++)
        {
            if (degree[i] > 0)
            {
                CJB = i; /*记录起始编号，要求字典序最小*/
                return true;
            }
        }
    }
    void dfs(int x)
    {
        for (int i = 'A'; i <= 'z'; i++)
        {
            if (g[x][i] > 0)
            {
                g[x][i] = 0;
                g[i][x] = 0;
                dfs(i);
            }
        }
        str[++ans] = x;
    }
    int main()
    {
        for (int i = 'A'; i <= 'z'; i++)
            fa[i] = i; /*并查集判断是否在同一连通块内*/
        cin >> n;
        for (int i = 1; i <= n; i++)
        {
            char s[5];
            cin >> s;
            g[s[0]][s[1]] = 1;
            g[s[1]][s[0]] = 1;
            degree[s[0]]++;
            degree[s[1]]++;
            int x = get_fa(s[0]), y = get_fa(s[1]);
            if (x != y)
                fa[x] = y;
        }
        if (!check())
        {
            printf("No Solution");
            return 0;
        }
        dfs(CJB); /*从起点递归*/
        for (int i = ans; i >= 1; i--)
            putchar(str[i]);
        return 0;
    }
    ```

## 哈密顿图

MKJ：2022-08-17 16:33:24 星期三：我不知道有什么用，甚至连一道例题都没找到，而且性质很古怪。

通过图中所有的点恰好一次的通路称为**哈密顿通路**。

通过图中所有的点恰好一次的回路称为**哈密顿回路**。

具有哈密顿回路的有向图或无向图是哈密顿图。

具有哈密顿通路的但没有哈密顿回路有向图或无向图是半哈密顿图。