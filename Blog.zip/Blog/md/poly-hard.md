## 多项式求逆

### 题目

多项式求逆，即给定一个多项式 $F(x)$，求一个多项式 $G(x)$，满足：

$$
F(x)*G(x)\equiv 1 (\bmod\,x^n)
$$

### 解法

假设我们已经知道了 $H(x)$，满足：

$$
F(x)*H(x)\equiv 1 (\bmod x^{\lceil\frac{n}{2}\rceil})
$$

又因为：

$$
F(x)*G(x)\equiv 1 (\bmod\,x^{\lceil\frac{n}{2}\rceil})
$$

两式相减得到：

$$
F(x)*(G(x)-H(x))\equiv 0 (\bmod x^{\lceil\frac{n}{2}\rceil})
$$

两边再同时除以 $F(x)$：

$$
(G(x)-H(x))\equiv 0 (\bmod x^{\lceil\frac{n}{2}\rceil})
$$

再同时平方：

$$
(G(x)-H(x))^2\equiv 0 (\bmod x^n)
$$

拆开括号：

$$
G(x)^2+H(x)^2-2*G(x)*H(x)\equiv 0 (\bmod\,x^n)
$$

再将 $F(x)$ 重新乘回去：

$$
F(x)G(x)^2+F(x)H(x)^2-2*F(x)*G(x)*H(x)\equiv 0 (\bmod\,x^n)
$$

将 $F(x)*G(x)\equiv 1 (\bmod\,x^{\lceil\frac{n}{2}\rceil})$ 代入：

$$
G(x)+F(x)H(x)^2-2*H(x)\equiv 0 (\bmod\,x^n)
$$

移项可得：

$$
G(x)\equiv H(x)*(2-F(x)H(x)) (\bmod\,x^n)
$$

就可以递归求解了。

### Q&A

Q：$(\bmod x^{\lceil\frac{n}{2}\rceil})$，为什么向上取整？

A：向上取整模多了可以在删去多余的，但是模少了恐怕就补不回来了。

Q：$ (x^{\lceil\frac{n}{2}\rceil})^2=x^n$？

A：还是那句话，多的部分可以抹去。

Q：递归边界？

A：$G(0)\equiv\frac{1}{F(0)}(\bmod\,n)$。

## 多项式求 ln

### 前置结论

- 复合函数求导

$f(g(x))'=f'(g(x))g'(x)$

- 求导公式和积分公式

$\ln'(x)=\frac{1}{x}$

$x^{a}{'}=ax^{a-1}$

$\int x^adx=\frac{1}{a+1}x^{a+1}$

### 题目

多项式求 $\ln$，给定多项式 $F(x)$，求多项式 $G(x)$ 满足：

$$
G(x)\equiv \ln F(x)
$$

### 解法

设 $f(x)=\ln(x)$。原式变为：

$$
G(x)=f(F(x))(\bmod\,x^n)
$$

两边同时求导：

$$
G(x)'=f'(F(x))F(x)'(\bmod\,x^n)
$$

将 $\ln'(x)=\frac{1}{x}$ 代入可得：

$$
G(x)'=\frac{F(x)'}{F(x)}(\bmod\,x^n)
$$

积分回去：

$$
G(x)=\int\frac{F(x)'}{F(x)}(\bmod\,x^n)
$$

似乎非常简短。

## 多项式 exp

前面的 inv & ln 都是前置知识哎 QWQ。

### 前置结论

对于一个函数要求 $F(G(x))\equiv 0$，则通过**牛顿迭代**得到（我不会证明）：

$$
G(x)=G_0(x)-\frac{F(G_0(x))}{F'(G_0(x))}
$$

### 题目

多项式求 $\exp$，给定多项式 $A(x)$，求多项式 $G(x)$ 满足

$$
G(x)\equiv e^{A(x)} (\bmod\,x^n)
$$

### 解法

两边同时取 $\ln$：

$$
\ln G(x)-A(x)\equiv 0 (\bmod\,x^n)
$$

代入前置结论的式子：

$$
F(G(x))=\ln G(x)-A(x)
$$

先暂时将 $A(x)$ 视为常数项，所以导数为 $0$。

则得到：$F'(G(x))=\ln'G(x)+A(x)'=\frac{1}{G(x)}$。

我们仍然假设已经求出了 $G_0(x)\equiv e^{A(x)} (\bmod\, x^{\lceil\frac{n}{2}\rceil})$。

类比前面的求逆，小的模数满足了，大的模数也满足，所以直接代入（其实是我不会证明）。

代入前置结论的式子可得：

$$
\begin{aligned}
G(x)
&\equiv G_0(x)-\frac{\ln{G_0(x)-A(x)}}{\frac{1}{G_0(x)}}(\bmod x^n)\\
&\equiv G_0(x)-G_0(x)(\ln{G_0(x)-A(x)})(\bmod x^n)\\
&\equiv G_0(x)(1-\ln{G_0(x)+A(x)})(\bmod x^n)\\
\end{aligned}
$$

### Q&A

Q：递归边界？

A：模板题目中给出了 $A(0)=0$，自然就是 $\ln G(0)-A(0)=0$，$G(0)=1$。

## 多项式开根

### 题目

多项式求逆，即给定一个多项式 $F(x)$，求一个多项式 $G(x)$，满足：

$$
G(x)^2\equiv F(x) (\bmod\,x^n)
$$

### 解法

像极了多项式求逆

假设我们已经知道了 $H(x)$，满足：

$$
H(x)^2\equiv F(x) (\bmod x^{\lceil\frac{n}{2}\rceil})
$$

那么：

$$
G(x)^2-H(x)^2\equiv 0(\bmod\,x^{\lceil\frac{n}{2}\rceil})
$$

两边同时平方：

$$
G(x)^4+H(x)^4-2*G(x)^2*H(x)^2\equiv 0(\bmod\,x^n)
$$

两边同时加 $4*G(x)^2*H(x)^2$：

$$
G(x)^4+H(x)^4+2*G(x)^2*H(x)^2\equiv 4*G(x)^2*H(x)^2(\bmod\,x^n)
$$

两边同时开方：

$$
G(x)^2+H(x)^2\equiv 2*G(x)*H(x)(\bmod\,x^n)
$$

代入 $F(x)\equiv G(x)^2(\bmod\,x^n)$ 得到：

$$
F(x)+H(x)^2\equiv 2*G(x)*H(x)(\bmod\,x^n)
$$

代入原式：

$$
G(x)\equiv \frac{F(x)+H(x)^2}{2H(x)}(\bmod\,x^n)
$$

### Q&A

Q：递归边界？

A：模板题目中给出了 $A(0)=1$，自然就是 $G(0)=\sqrt{A(0)}$，$G(0)=1$。