2-SAT 是基于 Tarjan 算法与强联通分量 SCC 的。

[【图联通性】Tarjan](http://marchkidjoe.mygamesonline.org/tarjan/ "图联通性，Tarjan")

---

## 2-SAT引入

SAT是适定性（Satisfiability）问题的简称。一般形式为 k -适定性问题，简称 k-SAT。当然这里研究 $k=2$ 的情况，即 2-SAT。

## 建边及现实意义

### 引入

A 与 E 有矛盾不能同时待着，C 与 D 必须都去，E 与 B 必须去 $1$ 个... ...。其实就可以把这些复杂的关系用图来表示。

### 解法

比如我们假设 $x$ 参加为 $x$，不参加为 $\neg x$，两个点之间的连边表示前者成立是后者一定成立。

举个例子：C 与 D 都参加可以表示为 $C\to D$，$\neg C\to \neg D$。E 与 B 必须去 $1$ 个，同理：$\neg E\to B$，$\neg B\to E$。

建完图之后，Tarjan SCC 缩点。

### 关系映射

有这两句话很好：

- $a$ 向 $b$ 连边表示选 $a$ 一定选 $b$。

- $\neg a$ 向 $a$ 连边表示一定选 $a$。

$$
\begin{aligned}
a\text{ and }b=true
&\iff (\neg a,a)\land (\neg b,b)\\
a\text{ and }b=false
&\iff (a,\neg b)\land (b,\neg a)\\
a\text{ or }b=true
&\iff(\neg a,b)\land (\neg b,a)\\
a\text{ or }b=false
&\iff(a,\neg a)\land (b,\neg b)\\
a\text{ xor }b=true
&\iff(a,\neg b)\land (b,\neg a)\land (\neg a,b)\land (\neg b,a)\\
a\text{ xor }b=false
&\iff(a,b)\land (b,a)\land (\neg a,\neg b)\land (\neg b,\neg a)\\
\end{aligned}
$$

### 解

对于有解情况输出方案，只需要输出**拓扑序**编号较大的就可以了。

但又考虑到 SCC 的奇妙性质，SCC 的编号就是**反拓扑序**，所以不必 toposort，直接比较 SCC 编号，输出 SCC 编号较小的即可。

那无解情况，只要判断 $x$ 和 $\neg x$ 是否在同一 SCC 内即可。因为 $x$ 和 $\neg x$ 不可能同时成立。

## 例题

2-SAT 主要就是建边，流程基本都一样。

### [【模板】2-SAT 问题](https://www.luogu.com.cn/problem/P4782 "【模板】2-SAT 问题")

1. 题意

    给定 $n$ 个变量，$m$ 条形如 $x_a=k\lor x_b=k,k\in\{0,1\}$。求一组可行解。

    输入：

    第 $1$ 行：有 $2$ 个整数，$n,m$。

    第 $2$ ~ $m+1$ 行：每行 $4$ 个整数，$a,k_1,b,k_2$，表示题目中的 $1$ 条限制。

    输出：

    共 $1$ ~ $2$ 行：

    若有解，共 $2$ 行：第 $1$ 行输出 ```POSSIBLE```；第 $2$ 行 $n$ 个整数，表示一组可行解 $\{x\}$。

    若无解，共 $1$ 行：输出 ```IMPOSSIBLE```。

2. 思路

    其实就是对于 $a\text{ or }b=true$ 进行变形。

    $$
    \begin{cases}
    a\lor b
    &\iff (\neg b,a)\land (\neg a,b)\\
    \neg a\lor b
    &\iff (\neg b,\neg a)\land (a,b)\\
    a\lor \neg b
    &\iff (b,a)\land (\neg a,\neg b)\\
    \neg a\lor \neg b
    &\iff (b,\neg a)\land (a,\neg b)\\
    \end{cases}
    $$

3. 流程

    - 按以上方法对每个限制建边。

    - Tarjan SCC 强联通分量。

    - 判断是否有解，输出方案。

### [[POI2001] 和平委员会](https://www.luogu.com.cn/problem/P5782 "P5782 [POI2001] 和平委员会")

1. 题意

    $\Huge{CJB}$ 破费举办新的课外活动，但是名额(￥)有限，只允许**一半**的人参加。选取的规则是这样的：现在共有 $n$ 组，每组 $2$ 人，**每 1 组只选取 1 人**，对于这 $2n$ 个人依次编号 $1$ ~ $2n$，规定第 $i$ 组的人的编号分别为 $2i-1,2i$。但是平常同学们未免会有自己讨厌的人，现在给定 $m$ 个关系，表示两个人**互相讨厌**。现在 CJB 迫切知道该选哪些同学，且选定的同学之间都可以**和睦相处**。最后 CJB 把这个艰巨的任务交给了聪明的你。

    输入：

    第 $1$ 行：两个整数，$n,m$。

    第 $2$ ~ $m+1$ 行：每行 $4$ 个整数，$a,b$，表示 $a,b$ 之间有矛盾。

    输出：

    共 $1$ 行：

    若有解，$n$ 个整数，表示选取的人的编号。

    若无解，输出 ```NIE```。

2. 思路

    这里只提供建图思路，因为建完图这个题就没了。先形成**共识**：对于编号为 $x$ 的人，$x$ 表示 $x$ 参加，$n+x$ 表示 $x$ 不参加。

    考虑第一条限制：一组内只能去一个人。

    假设当前为第 $x$ 组，这组两个人编号分别为 $a,b$。

    其实就是 $a$ 不参加，$b$ 必须参加；$b$ 不参加，$a$ 必须参加。$a$ 参加，$b$ 不能参加；$b$ 参加，$a$ 不能参加。

    那就可以这样建边：

    $$
    (2n+a,b)\land(2n+b,a)\land(a,2n+b)\land(b,2n+a)
    $$

    再解决第二条限制：两人互相讨厌。

    设两个有矛盾的人编号分别为 $x,y$。

    可以转化为这样的关系：$x$ 参加，$y$ 不能参加；$y$ 参加，$x$ 不能参加。

    建边比第一条限制还要简单：

    $$
    (x,2n+y)\land(y,2n+x)
    $$

    所有的边连接完之后，Tarjan SCC，输出方案。

3. Code

    ```cpp
    #include <bits/stdc++.h>
    const int N = 2e4 + 10;
    const int M = 2e5 + 10;
    using namespace std;
    vector<int> son[N << 1];
    int n, m;
    namespace tarjan
    {
        int scc[N << 1];
        int dfn[N << 1];
        int low[N << 1];
        int s[N << 1];
        bool vis[N << 1];
        int top;
        int dcnt;
        int scnt;
        void dfs(int u) /*Tarjan-SCC*/
        {
            low[u] = dfn[u] = ++dcnt;
            s[++top] = u;
            vis[u] = true;
            for (int i = 0; i < son[u].size(); i++)
            {
                int v = son[u][i];
                if (!dfn[v])
                {
                    dfs(v);
                    low[u] = min(low[u], low[v]);
                }
                else if (vis[v])
                    low[u] = min(low[u], dfn[v]);
            }
            if (dfn[u] == low[u])
            {
                ++scnt;
                int now = -1;
                do
                {
                    now = s[top--];
                    vis[now] = false;
                    scc[now] = scnt;
                } while (top > 0 && now != u);
            }
        }
        void Tarjan()
        {
            for (int i = 1; i <= n; i++)
                if (!dfn[i])
                    dfs(i);
        }
    } // namespace tarjan
    using namespace tarjan;
    int main()
    {
        read(n, m);
        n <<= 1; /*人有2*n个*/
        for (int i = 1; i < n; i += 2) /*第1条限制*/
        {
            son[n + i].push_back(i + 1);
            son[n + i + 1].push_back(i);
            son[i].push_back(n + i + 1);
            son[i + 1].push_back(n + i);
        }
        for (int i = 1; i <= m; i++) /*第2条限制*/
        {
            int a, b;
            read(a, b);
            son[a].push_back(n + b);
            son[b].push_back(n + a);
        }
        Tarjan();
        for (int i = 1; i <= n; i++) /*判断无解*/
        {
            if (scc[i] == scc[n + i])
            {
                printf("NIE");
                return 0;
            }
        }
        for (int i = 1; i <= n; i++) /*输出方案*/
        {
            if (scc[i] < scc[n + i]) /*输出SCC序较小的或拓扑序较大的*/
            {
                write(i);
                putchar('\n');
            }
        }
        return 0;
    }
    ```