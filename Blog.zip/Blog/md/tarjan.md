Update：2022-08-12 22:55:41 修改了割点与桥的判定法则，修改了某个变量下标错误，微调了图片与代码。

Update：2022-08-19 17:46:50 修改了代码的判断条件，更新了语法。

Update：2022-10-18 06:13:46 更新了语法。

---

## Tarjan算法

### 介绍

Robert E. Tarjan（罗伯特·塔扬，1948~xxxx），生于美国加州波莫纳，计算机科学家。

Tarjan 发明了很多算法和数据结构。不少他发明的算法都以他的名字命名，以至于有时会让人混淆几种不同的算法。比如求各种连通分量的 Tarjan 算法，求 LCA（Lowest Common Ancestor，最近公共祖先）的 Tarjan 算法。并查集、Splay、Toptree 也是 Tarjan 发明的。

我们这里要介绍的是在有向图中求**强连通分量，点、边双联通分量**的 Tarjan 算法。（来自OIWIKI）

### 算法

1. 总之，$\Huge{Tarjan}$ 很巨，（~~名字也很巨~~）。

2. 定义

    首先了解几个定义（~~其实有些没啥用~~）。

    ![](https://oi-wiki.org//graph/images/dfs-tree.svg)

    （图片来源于OIWIKI）

    - 树枝边：图中黑色的边，dfs 搜索树上得边。

    - 返祖边：图中的红边，望文生义，就是返回了当前节点的祖先。

    - 横叉边：图中的蓝边，通过这条边可以走到一个已经搜索过的节点，但去往的节点**不是**当前节点的祖先。

    - 前向边：图中的绿边，通过非树枝边搜到了自身子树的节点。

    当然这些都不太重要，看几个稍微重要一点的。

    - 时间戳(dfn)：dfs 搜索序。

    - 回溯值(low)：假设我们把搜索的路径放进一个栈(stack)内，$low$ 为当前节点通过**非树枝边**到达的**在栈内**节点 $dfn$ 最小值。

3. 算法流程

    初始化：

    当搜到节点 $u$ 时，$dfn_u=low_u=++cnt$，$cnt$ 为当前 dfs 序，并将 $u$ 进栈，标记 $u$ 在栈内。

    设当前节点为 $u$，我们枚举 $u$ 的每个可以到达的节点，记为 $v$。

    分以下 $3$ 种情况：

    $(1)$.当 $v$ 没被访问时，即 $dfn_v=0$，直接递归。此时用 $low_v$ 更新 $low_u$，回溯时更新 $low_u=min(low_u,low_v)$。

    $(2)$.当 $v$ 被访问时，即 $dfn_v\not=0$，且 $v$ 在栈内，此时用 $dfn_v$ 更新 $low_u$，$low_u=min(low_u,dfn_v)$。

    $(3)$.当 $v$ 被访问时，且 $v$ 不在栈内，证明 $v$ 已经处理过了，不用管这种情况直接跳过。

    最后判断 $dfn$ 与 $low$ 的关系。但由于三种分量的弹栈条件不同，在下面分开描述。

4. 伪代码

    ```cpp
    void dfs(int u, int father)
    {
        s[++top] = u;  /*入栈*/
        vis[u] = true; /*标记入栈*/
        low[u] = dfn[u] = ++cnt;
        for (v)
        {
            if (v != father) /*防止返回父节点（应题意而定，因为有时必须特判，有时必须不特判）*/
            {
                if (!dfn[v]) /*情况1*/
                {
                    dfs(v, u);
                    low[u] = min(low[u], low[v]);
                }
                else if (vis[v]) /*情况2*/
                {
                    low[u] = min(low[u], dfn[v]);
                }
            }
        }
    }
    void Tarjan(int n)
    {
        for (int i = 1; i <= n; i++)
            if (!dfn[i]) /*原图可能不连通*/
                dfs(i, 0);
    }
    ```

## 割点

1. 定义

    定义一个无向图中的点，某点为割点当且仅当删除此点后原图变为两个及两个以上的子图。

2. 割点判定法则

    $$
    \boxed
    {
    low_v\geqslant dfn_u
    }
    $$

3. 证明

    当 $low_v\geqslant dfn_u$ 时，说明 $v$ 肯定无法通过其他的边走到比 $u$ 更早的节点，此时把 $u$ 删掉，图必然分为多个子图。

    特别的：对于**根节点**，是整个搜索开始的节点，而不是当前双联通分量的祖先。需判断他有多于 $1$ 个儿子。

    $$
    \boxed
    {
    son_{root}\geqslant 2
    }
    $$

    如图，尽管 $dfn_2\gt low_1$，但是可以发现 $1$ 并不是割点。

    ![](http://marchkidjoe.mygamesonline.org/wp-content/uploads/2022/08/tarjan01.png)

4. [【模板】割点](https://www.luogu.com.cn/problem/P3388)

## 桥

1. 定义

    定义一个无向图中的边，某点为桥当且仅当删除此边后原图变为两个及两个以上的子图。

2. 桥判定法则

    $$
    \boxed
    {
    low_v\gt dfn_u
    }
    $$

3. 证明

    证明类比割点，当 $low_v\gt dfn_u$ 时，说明 $v$ 肯定无法通过其他的边走到比 $u$ 更早的节点，此时把这条边删掉，图必然分为多个子图。

    **树枝边**一定是桥。

## 图的联通性

### 强联通分量

1. 定义

    有向图 G 强连通是指，G 中任意两个结点连通。

    强连通分量(Strongly Connected Components，SCC)的定义是：极大的强连通子图。

    ![](http://marchkidjoe.mygamesonline.org/wp-content/uploads/2022/08/tarjan02.png)

    如图 $\{1,2,3\}$ 就是一个强连通分量，而 $\{3,4,5\}$ 不是，也就是说，一个点集内**任意两点**可以相互到达就是一个强连通分量。

2. 求取方法

    我们一般用 Tarjan 算法求取。时间复杂度 $O(n+m)$。

    弹栈条件：$low=dfn$，即当前节点为当前强连通分量的祖先。我们一直弹栈，直到将当前节点弹出。

3. 应用

    缩点：将有环的有向连通图的问题转化为有向无环图的问题。

4. Code

    ```cpp
    void dfs(int u)
    {
        s[++top] = u;
        vis[u] = true;
        low[u] = dfn[u] = ++cnt;
        for (v)
        {
            if (!dfn[v])
            {
                dfs(v);
                low[u] = min(low[u], low[v]);
            }
            else if (vis[v])
            {
                low[u] = min(low[u], dfn[v]);
            }
        }
        if (low[u] == dfn[u])
        {
            int point = -1;
            ++total;
            do
            {
                point = s[top--];
                group[point] = total;
                scc[total].push_back(point);
                vis[point] = false;
            } while (top > 0 && point != u);
        }
    }
    void Tarjan(int n)
    {
        for (int i = 1; i <= n; i++)
            if (!dfn[i])
                dfs(i);
    }
    ```

### 边双连通分量

1. 边双联通

    在一张连通的无向图中，对于两个点 $u$ 和 $v$，如果无论删去哪条边（只能删去一条）都不能使它们不连通，我们就说 $u$ 和 $v$ **边双连通**。

2. 边双联通分量

    边双连通分量是定义在无向图当中的，一个不存在割边的子图。也就是说一个边双连通分量中任意两点都可以走不重复的**边**可以互相到达。

    比如下图，为一个边双连通分量 $\{1,2,3,4,5,6,7\}$。

    ![](http://marchkidjoe.mygamesonline.org/wp-content/uploads/2022/08/tarjan03.png)

3. 求取方法

    Tarjan 算法求取。

    弹栈条件：$low=dfn$，即当前节点为当前边双连通分量的祖先。我们一直弹栈，直到将当前节点弹出。其实与强连通分量差不多。

4. Code

    ```cpp
    void dfs(int u, int father)
    {
        s[++top] = u;
        vis[u] = true;
        low[u] = dfn[u] = ++cnt;
        for (v)
        {
            if (v != father)
            {
                if (!dfn[v])
                {
                    dfs(v, u);
                    low[u] = min(low[u], low[v]);
                }
                else if (vis[v])
                {
                    low[u] = min(low[u], dfn[v]);
                }
            }
        }
        if (low[u] == dfn[u])
        {
            int point = -1;
            ++total;
            do
            {
                point = s[top--];
                group[point] = total;
                e_dcc[total].push_back(point);
                vis[point] = false;
            } while (top > 0 && point != u);
        }
    }
    void Tarjan(int n)
    {
        for (int i = 1; i <= n; i++)
            if (!dfn[i])
                dfs(i, 0);
    }
    ```

5. 应用

    缩点：将图的问题转化为树的问题。

6. [【模板】边双连通分量](https://www.luogu.com.cn/problem/P8436)

    [【模板】缩点](https://www.luogu.com.cn/problem/P3387)

### 点双联通分量

1. 点双联通

    在一张连通的无向图中，对于两个点 $u$ 和 $v$，如果无论删去哪个点（只能删去一个，且不能删 $u,v$ ）都不能使它们不连通，我们就说 $u$ 和 $v$ **点双连通**。

2. 点双联通分量

    边双连通分量是定义在无向图当中的，图中任意两点都可以有两条不重复（点）的路径可以互相到达的，可以理解将以交点为分割点，边双联通分量的在交点处分裂了。。

    比如下图，把 $1$ 分裂了，有 $3$ 个点双连通分量 $\{1,2,7\};\{1,3,4\};\{1,5,6\}$。

    ![](http://marchkidjoe.mygamesonline.org/wp-content/uploads/2022/08/tarjan04.png)

3. 求取方法

    Tarjan。

    弹栈条件：设当前节点为 $u$，我们枚举 $u$ 的每个可以到达的节点，记为 $v$。当 $low_v\geqslant dfn_u$，即当前节点为当前点双连通分量的祖先，我们一直弹栈，直到 $v$ 被弹出，注意是 $v$，也就是弹出 $u$ 的子树，然后再将 $u$ 也放进当前点双联通分量内，注意 $u$ 不弹出。

4. Code

    ```cpp
    void dfs(int u, int father)
    {
        s[++top] = u;
        vis[u] = true;
        low[u] = dfn[u] = ++cnt;
        for (v)
        {
            if (v != father)
            {
                if (!dfn[v])
                {
                    dfs(v, u);
                    low[u] = min(low[u], low[v]);
                    if (low[v] >= dfn[u])
                    {
                        int point = -1;
                        ++total;
                        do
                        {
                            point = s[top--];
                            group[point].push_back(total); /*一个点可能属于多个v-dcc*/
                            v_dcc[total].push_back(point);
                            vis[point] = false;
                        } while (top > 0 && point != v); /*v*/
                        group[u].push_back(total);
                        v_dcc[total].push_back(u);
                    }
                }
                else if (vis[v])
                {
                    low[u] = min(low[u], dfn[v]);
                }
            }
        }
    }
    void Tarjan(int n)
    {
        for (int i = 1; i <= n; i++)
            if (!dfn[i])
                dfs(i, 0);
    }
    ```

5. 应用

    圆方树：将图的问题转化为树的问题。

6. [【模板】点双连通分量](https://www.luogu.com.cn/problem/P8435)