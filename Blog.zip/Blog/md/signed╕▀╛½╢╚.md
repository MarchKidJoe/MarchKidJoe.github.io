说明戳 [here](http://marchkidjoe.mygamesonline.org/bignum/ "here")，普通高精度，若追求**乘法**效率（不包括除法），建议[压位高精度](http://marchkidjoe.mygamesonline.org/fast_signed_bignum/ "压位高精度")。
函数
- a.size()        a 的数位个数。
- a.length()    a 的数位个数。
- a.odd()        a 为奇数返回 1，否则返回 0。
- a.clear()        清空 a，注意清空 a，此时 a 不是 0，而是无意义的。可以通过 a = 0 恢复使用。
- a.input()        输入 a。
- a.output()    输出 a。

---

```cpp
/*===================*/
/*Author:MarchKid_Joe*/
/*Update:2022.08.25  */
/*===================*/
#include<bits/stdc++.h>
using namespace std;
namespace Bignum
{
    /*You can change size here.*/
    const int Big=20;
    template <typename Type> inline void read(Type &n)
    {
        Type w=1;char x=getchar();n=0;
        while(x<'0'||x>'9'){if(x=='-')w=-1;x=getchar();}
        while(x>='0'&&x<='9'){n=(n<<1)+(n<<3)+(x^48);x=getchar();}
        n*=w;
    }
    template <typename Type> inline void write(Type x)
    {
        if(x<0) putchar('-'),x=-x;
        if(x>9) write(x/10);
        putchar(x%10+'0');
    }
    /*something you can't use.*/
    bool bignum_Compare(int l,int r,short *x,short *y,int Len)
    {
        if(l-r+1!=Len) return l-r+1>Len;
        for(int i=l;i>=r;i--)
            if(*(x+i)!=*(y+i-r))
                return *(x+i)>*(y+i-r);
        return true;
    }
    template <typename Type>
    inline Type big_abs(const Type &x)    {return x<0?-x:x;}
    /*BIGNUM*/
    class bignum
    {
    private:
        int Length;
        short s[Big];
        bool negative;
        void reverse()            {for(int i=0;i<(Length>>1);i++){short x=s[i];s[i]=s[Length-i-1];s[Length-i-1]=x;}}
        void get_str(char k)    {do{k=getchar();if(k=='-')negative=true;}while(k<'0'||k>'9');while(k>='0'&&k<='9'){s[Length++]=k-'0',k=getchar();}}
        void del()                {while(!s[Length-1]&&Length>1) --Length;if(zero()) negative=false;}
        bool zero()                {return (!s[0])&&(Length==1);}
        static bignum plus(const bignum &x,const bignum &y)
        {
            bignum ANS;
            ANS.Length=max(x.Length,y.Length)+1;
            for(int i=0;i<ANS.Length;i++)
            {
                ANS.s[i]+=x.s[i]+y.s[i];
                ANS.s[i+1]+=(ANS.s[i]>=10);
                ANS.s[i]-=10*(ANS.s[i]>=10);
            }
            ANS.del();
            return ANS; 
        }
        static bignum minus(const bignum &x,const bignum &y)
        {
            bignum ANS;
            ANS.Length=max(x.Length,y.Length);
            for(int i=0;i<ANS.Length;i++)
            {
                ANS.s[i]+=x.s[i]-y.s[i];
                ANS.s[i+1]-=(ANS.s[i]<0);
                ANS.s[i]+=10*(ANS.s[i]<0);
            }
            ANS.del();
            return ANS; 
        }
    public:
        bignum()                        {memset(s,0,sizeof(s));negative=false;Length=1;}
        void clear()                    {memset(s,0,sizeof(s));negative=false;Length=0;}
        void output()                    {if(negative) putchar('-');for(int i=Length-1;i>=0;i--) putchar(s[i]+'0');}
        void input()                    {clear();get_str(' ');reverse();del();}
        int size()                        {return Length;}
        int length()                    {return Length;}
        bool odd()                        {return s[0]&1;}
        bignum(const char x)                        {*this=x;}
        bignum(const char *x)                        {*this=x;}
        bignum(const string x)                        {*this=x;}
        bignum(const unsigned long long x)            {*this=x;}
        bignum(const unsigned int x)                {*this=x;}
        bignum(const unsigned short x)                {*this=x;}
        bignum(const long long x)                    {*this=x;}
        bignum(const int x)                            {*this=x;}
        bignum(const short x)                        {*this=x;}
        bignum operator = (const char x)            {clear();s[Length++]=x-'0';return *this;}
        bignum operator = (const char *x)            {clear();int len=strlen(x);bool end=false;if(x[0]=='-'){negative=true;end=true;}while(len>end) s[Length++]=x[--len]-'0';del();return *this;}
        bignum operator = (const string x)            {clear();int len=x.size( );bool end=false;if(x[0]=='-'){negative=true;end=true;}while(len>end) s[Length++]=x[--len]-'0';del();return *this;}
        bignum operator = (unsigned long long x)    {clear();do{s[Length++]=x%10;}while(x/=10);return *this;}
        bignum operator = (unsigned int x)            {clear();do{s[Length++]=x%10;}while(x/=10);return *this;}
        bignum operator = (unsigned short x)        {clear();do{s[Length++]=x%10;}while(x/=10);return *this;}
        bignum operator = (long long x)                {clear();negative=(x<0);x=big_abs(x);do{s[Length++]=x%10;}while(x/=10);return *this;}
        bignum operator = (int x)                    {clear();negative=(x<0);x=big_abs(x);do{s[Length++]=x%10;}while(x/=10);return *this;}
        bignum operator = (short x)                    {clear();negative=(x<0);x=big_abs(x);do{s[Length++]=x%10;}while(x/=10);return *this;}
        bignum operator ++ ()                        {return *this+=1,*this;}
        bignum operator ++ (int)                    {return *this+=1,*this-1;}
        bignum operator -- ()                        {return *this-=1,*this;}
        bignum operator -- (int)                    {return *this-=1,*this+1;}
        bignum operator += (const bignum &x)        {return *this=*this+x,*this;}
        bignum operator -= (const bignum &x)        {return *this=*this-x,*this;}
        bignum operator *= (const bignum &x)        {return *this=*this*x,*this;}
        bignum operator /= (const bignum &x)        {return *this=*this/x,*this;}
        bignum operator %= (const bignum &x)        {return *this=*this%x,*this;}
        bignum operator /= (const long long &x)        {return *this=*this/x,*this;}
        bignum operator %= (const long long &x)        {return *this=*this%x,*this;}
        friend bignum operator - (bignum x)            {x.negative^=(!x.zero()); return x;}
        friend bool operator ! (const bignum &x)    {return x.s[0]==0&&x.Length==1;}
        friend bool operator < (const bignum &x,const bignum &y)    {if(x.negative!=y.negative)return x.negative;if(x.Length!=y.Length) return (x.Length<y.Length)^x.negative;for(int i=x.Length-1;i>=0;i--)if(x.s[i]!=y.s[i])return (x.s[i]<y.s[i])^x.negative;return false;}
        friend bool operator > (const bignum &x,const bignum &y)    {return y<x;}
        friend bool operator <= (const bignum &x,const bignum &y)    {return !(y<x);}
        friend bool operator >= (const bignum &x,const bignum &y)    {return !(x<y);}
        friend bool operator == (const bignum &x,const bignum &y)    {return !(x<y||y<x);}
        friend bool operator != (const bignum &x,const bignum &y)    {return x<y||y<x;}
        friend bignum operator + (const bignum &x,const bignum &y)
        {
            bignum ANS;
            if(x.negative==y.negative)
                ANS=plus(x,y),ANS.negative=x.negative;
            else 
                ANS=minus(max(big_abs(x),big_abs(y)),min(big_abs(x),big_abs(y))),ANS.negative=(x.negative&&big_abs(x)>big_abs(y))||(!x.negative&&big_abs(y)>big_abs(x));
            return ANS;
        }
        friend bignum operator - (const bignum &x,const bignum &y)
        {
            bignum ANS;
            if(x.negative!=y.negative)
                ANS=plus(x,y),ANS.negative=x.negative;
            else 
                ANS=minus(max(big_abs(x),big_abs(y)),min(big_abs(x),big_abs(y))),ANS.negative=(x.negative&&big_abs(x)>big_abs(y))||(!x.negative&&big_abs(y)>big_abs(x));
            return ANS;
        }
        friend bignum operator * (const bignum &x,const bignum &y)
        {
            if(!x||!y) return 0;
            bignum ANS;
            ANS.Length=x.Length+y.Length;
            ANS.negative=x.negative^y.negative;
            for(int i=0;i<x.Length;i++)
                for(int j=0;j<y.Length;j++)
            {
                ANS.s[i+j]+=x.s[i]*y.s[j];
                ANS.s[i+j+1]+=ANS.s[i+j]/10;
                ANS.s[i+j]%=10;
            }
            ANS.del();
            return ANS;
        }
        friend bignum operator / (const bignum &x,const long long &y)
        {
            if(!x) return 0;
            if(!y) {short re=0;short RE=1/re;return 0;}
            bignum ANS;
            ANS.Length=x.Length;
            ANS.negative=(x.negative&&y>0)||(!x.negative&&y<0);
            long long tot=0;
            for(int i=x.Length-1;i>=0;i--)
            {
                tot=tot*10+x.s[i];
                ANS.s[i]+=tot/y;
                tot%=y;
            }
            ANS.del();
            return ANS;
        }
        friend bignum operator / (bignum x,bignum y)
        {
            if(!x) return 0;
            if(!y) {short re=0;short RE=1/re;return 0;}
            bignum ANS;
            int l=x.Length-1,r=x.Length-y.Length;
            ANS.Length=x.Length;
            ANS.negative=x.negative^y.negative;
            while(r>=0)
            {
                while(bignum_Compare(l,r,x.s,y.s,y.Length))
                {
                    for(int i=r;i<=l-(l-r==y.Length);i++)
                    {
                        x.s[i]-=y.s[i-r];
                        x.s[i+1]-=(x.s[i]<0);
                        x.s[i]+=10*(x.s[i]<0);
                    }
                    while(!x.s[l]&&l>0) l--;
                    ANS.s[r]++;
                }
                r--;
            }
            ANS.del();
            return ANS;
        }
        friend bignum operator % (const bignum &x,const long long &y)
        {
            if(!x) return 0;
            if(!y) {short re=0;short RE=1%re;return 0;}
            long long tot=0;
            for(int i=x.Length-1;i>=0;i--)
            {
                tot=tot*10+x.s[i];
                tot%=y;
            }
            return x.negative?-tot:tot;
        }
        friend bignum operator % (bignum x,bignum y)
        {
            if(!x) return 0;
            if(!y) {short re=0;short RE=1%re;return 0;}
            int l=x.Length-1,r=x.Length-y.Length;
            while(r>=0)
            {
                while(bignum_Compare(l,r,x.s,y.s,y.Length))
                {
                    for(int i=r;i<=l-(l-r==y.Length);i++)
                    {
                        x.s[i]-=y.s[i-r];
                        x.s[i+1]-=(x.s[i]<0);
                        x.s[i]+=10*(x.s[i]<0);
                    }
                    while(!x.s[l]&&l>0) l--;
                }
                r--;
            }
            x.del();
            return x;
        }
    };
    /*ex*/
    template <typename TYPE>
    TYPE number(const bignum &x)            {TYPE K=0;for(int i=x.Length-1;i>=0;i--) K=K*10+x.s[i];return K;}
    template <typename Type,typename...Etc>
    inline void read(Type &n,Etc &...etcs)    {read(n);read(etcs...);}
    inline void read(bignum &x)                {x.input();}
    inline void write(bignum x)                {x.output();}
}
using namespace Bignum;
```