## 中国剩余定理

见[数论【易】中国剩余定理](http://marchkidjoe.mygamesonline.org/math-easy/ "数论【易】中国剩余定理")

## 拓展中国剩余定理

原思路见[数论【难】拓展中国剩余定理](http://marchkidjoe.mygamesonline.org/math-hard/ "数论【难】拓展中国剩余定理")

### 背景

拓展中国剩余定理是在中国剩余定理的基础上不保证模数互质。

提供了一种新的思路：

合并给定方程组：

$$
\begin{cases}
x\equiv a_1(\bmod\,p_1)\qquad①\\
x\equiv a_2(\bmod\,p_2)\qquad②\\
\end{cases}
$$

先前的合并方法是联立求解。现在提供一个新的思路：

### 新思路

假设我们此时已经得知了前几个同余方程合并后的结果记为 $ans$，前几个同余方程合并后的模数记为 $m$。

假设新加入的式子为：

$$
x\equiv a(\bmod\,p)
$$

合并就是要让新加入的式子满足：

$$
ans+k_1m\equiv a(\bmod\,p)
$$

又到了化式子的时候：

$$
k_1m+k_2p=a-ans
$$

于是又变成了线性方程求解，记得判断无解情况。线性方程求解参考[数论【难】-二元一次不定方程](http://marchkidjoe.mygamesonline.org/math-hard/ "数论【难】-二元一次不定方程")。

求出 $k_1$ 后，代入原式可得到新的 $ans$ 和新的模数 $m$。

$$
\begin{cases}
&ans_{new}=ans+k_1m\\
&m_{new}=lcm(m,p)\\
\end{cases}
$$

## 再拓展中国剩余定理

### 背景

再拓展中国剩余定理可以说是在拓展中国剩余定理的基础上加上了系数，仍然是模数不保证互质。

仿照拓展中国剩余定理的思路。

合并给定方程组：

$$
\begin{cases}
k_1x\equiv a_1(\bmod\,p_1)\qquad①\\
k_2x\equiv a_2(\bmod\,p_2)\qquad②\\
\end{cases}
$$

### 解法

依照以上思路，我们仍然假设此时已经求出了前几个方程合并后的结果和模数，分别记做 $ans,m$。

设新加入的式子为：

$$
kx\equiv a(\bmod\,p)
$$

现在其实就是让新加入的式子满足：

$$
k\times(ans+k_1m)\equiv a(\bmod\,p)
$$

化简得：

$$
k_1(k\times m)+k_2p\equiv a-k\times ans
$$

又变成了熟悉的线性方程求解。

解得 $k_1$ 后代入可得新的 $ans$ 和模数 $m$。

$$
\begin{cases}
&ans_{new}=ans+k_1m\\
&m_{new}=m\times(\frac{p}{gcd(k\times m,p)})\\
\end{cases}
$$

提醒 $ans$ 不乘以 $k$，但是新的模数是 $\Large{k\times m}$ （Large）与 $p$ 的最小公倍数。

### 例题

[[NOI2018] 屠龙勇士](https://www.luogu.com.cn/problem/P4774 "[NOI2018] 屠龙勇士")

## PS

最后再补一下这种新思路的初始化：$ans=0,m=1$。

原因很简单：

$$
x\equiv 0(\bmod\,1)
$$

这个式子对合并没有影响，而且一眼就看出来其中一个可行解 $ans=0$，其实 $ans$ 可以设为任意的整数，毕竟任何整数模以 $1$ 都是 $\Large{0}$。