Update：2022-09-04 11:06:36 星期日
说明戳 [here](http://marchkidjoe.mygamesonline.org/bignum/ "here")，若使用高精度与高精度之间运算的**除法**和**取模**自行加拓展包，具体说明见拓展包，若使用**乘法与加法**可以**保证效率远大于**普通高精度。

拓展

1. [vector 压位高精度拓展：高精度除以/模高精度](https://www.luogu.com.cn/paste/j1aakavc)

2. [  vector 压位高精度拓展：NTT 乘法高精度](https://www.luogu.com.cn/paste/gy171dq9)

函数

- a.number()    将 a 转化为整数类型，返回类型为 long long。

- a.size()        a 的**占用空间**个数。
- a.length()    a 的**数位**个数。
- a.odd()        a 为奇数返回 1，否则返回 0。
- a.zero()        a 为 0 返回 1，否则返回 0。
- a.clear()        清空 a，注意清空 a，此时 a 不是数字 0，而是无意义的。可以通过 a = 0 恢复使用。
- a.input()        输入 a。
- a.output()    输出 a。
- a.del()        删除前导 0。（用不到）。
- a.get(x)        统计数字位数。（用不到）。
- a.reverse()    数组翻转。（用不到）。

成员

- vector  s; 存储数字。
- bool negative; 正负性。正数返回 1；负数返回 0。特殊的：0 默认为正。

---

```cpp
#include<vector>
#include<cstdio>
using namespace std;
namespace Bignum
{
    #define NTTMUL 0
    #define bit 9/*You can change sth here.*/
    #if NTTMUL==1
    typedef int Type;
    #elif bit==1
    typedef char Type;
    #elif bit==2
    typedef short Type;
    #elif bit<=4
    typedef int Type;
    #else
    typedef long long Type;
    #endif
    typedef long long ll;
    const constexpr ll bit_pow[20]={1,(ll)10,(ll)1e2,(ll)1e3,(ll)1e4,(ll)1e5,(ll)1e6,(ll)1e7,(ll)1e8,(ll)1e9,(ll)1e10,(ll)1e11,(ll)1e12,(ll)1e13,(ll)1e14,(ll)1e15,(ll)1e16,(ll)1e17,(ll)1e18};
    template <typename TP> inline void read(TP &n)
    {
        TP w=1;char x=getchar();n=0;
        while(x<'0'||x>'9'){if(x=='-')w=-1;x=getchar();}
        while(x>='0'&&x<='9'){n=(n<<1)+(n<<3)+(x^48);x=getchar();}
        n*=w;
    }
    template <typename TP> inline void write(TP x)
    {
        if(x<0) putchar('-'),x=-x;
        if(x>9) write(x/10);
        putchar(x%10+'0');
    }
    template <typename TP,typename...Etc>
    inline void read(TP &n,Etc &...etcs){read(n);read(etcs...);}
    /*BIGNUM*/
    class bignum;
    bignum abs(const bignum &);
    bignum operator - (bignum);
    bool operator ! (const bignum &);
    bool operator < (const bignum &,const bignum &);
    bool operator > (const bignum &,const bignum &);
    bool operator <= (const bignum &,const bignum &);
    bool operator >= (const bignum &,const bignum &);
    bool operator == (const bignum &,const bignum &);
    bool operator != (const bignum &,const bignum &);
    bignum operator + (const bignum &,const bignum &);
    bignum operator - (const bignum &,const bignum &);
    bignum operator * (const bignum &,const bignum &);
    bignum operator / (const bignum &,const ll &);
    bignum operator % (const bignum &,const ll &);
    bignum operator += (bignum &,const bignum &);
    bignum operator -= (bignum &,const bignum &);
    bignum operator *= (bignum &,const bignum &);
    bignum operator /= (bignum &,const ll &);
    bignum operator %= (bignum &,const ll &);
    struct bignum
    {
        vector <Type> s;
        bool negative;
        bignum()                {clear();s.emplace_back(0);}
        void clear()            {negative=false;s.clear();}
        void input(char k=' ')  {clear();int rest=0;do{k=getchar();if(k=='-')negative=true;}while(k<'0'||k>'9');while(k>='0'&&k<='9'){if(!rest)s.emplace_back(0);*(--s.end())=*(--s.end())*10+k-'0';if(++rest==bit)rest=0;k=getchar();}rest+=(!rest)*bit;for(int i=s.size()-1;i>=1;i--){s[i]+=(s[i-1]%bit_pow[bit-rest]*bit_pow[rest]);s[i-1]/=bit_pow[bit-rest];}reverse();del();}
        void output()           {if(negative) putchar('-');write(s[s.size()-1]);for(int i=s.size()-2,put;i>=0;i--){put=bit-get(s[i]);while(put-->0)putchar('0');write(s[i]);}}
        void reverse()          {for(int i=0;i<(s.size()>>1);i++){swap(s[i],s[s.size()-i-1]);}}
        void del()              {while(s.size()>1&&!(*(--s.end()))) s.pop_back();if(zero()) negative=false;}
        int get(Type x)         {int cnt=0;while(x){x/=10;++cnt;}return cnt+(!cnt);}
        int size()              {return s.size();}
        int length()            {return bit*(s.size()-1)+get(s[s.size()-1]);}
        bool odd()              {return s[0]&1;}
        bool zero()             {return (!s[0])&&(s.size()==1);}
        ll number()             {ll K=0;for(int i=s.size()-1;i>=0;i--) K=K*bit_pow[bit]+s[i];return negative?-K:K;}
        short operator [](int x){return s[x/bit]%bit_pow[x%bit+1]/bit_pow[x%bit];}
        bignum(const bool x)                    {*this=x;}
        bignum(const char x)                    {*this=x;}
        bignum(const unsigned long long x)      {*this=x;}
        bignum(const unsigned int x)            {*this=x;}
        bignum(const unsigned short x)          {*this=x;}
        bignum(const long long x)               {*this=x;}
        bignum(const int x)                     {*this=x;}
        bignum(const short x)                   {*this=x;}
        bignum(const __int128 x)                {*this=x;}
        bignum operator = (const bool x)        {clear();s.emplace_back(x);return *this;}
        bignum operator = (const char x)        {clear();s.emplace_back(x-'0');return *this;}
        bignum operator = (unsigned long long x){clear();do{s.emplace_back(x%bit_pow[bit]);}while(x/=bit_pow[bit]);return *this;}
        bignum operator = (unsigned int x)      {clear();do{s.emplace_back(x%bit_pow[bit]);}while(x/=bit_pow[bit]);return *this;}
        bignum operator = (unsigned short x)    {clear();do{s.emplace_back(x%bit_pow[bit]);}while(x/=bit_pow[bit]);return *this;}
        bignum operator = (long long x)         {clear();negative=(x<0);x=x>=0?x:-x;do{s.emplace_back(x%bit_pow[bit]);}while(x/=bit_pow[bit]);return *this;}
        bignum operator = (int x)               {clear();negative=(x<0);x=x>=0?x:-x;do{s.emplace_back(x%bit_pow[bit]);}while(x/=bit_pow[bit]);return *this;}
        bignum operator = (short x)             {clear();negative=(x<0);x=x>=0?x:-x;do{s.emplace_back(x%bit_pow[bit]);}while(x/=bit_pow[bit]);return *this;}
        bignum operator = (__int128 x)          {clear();negative=(x<0);x=x>=0?x:-x;do{s.emplace_back(x%bit_pow[bit]);}while(x/=bit_pow[bit]);return *this;}
        bignum operator ++ ()                   {return *this+=1,*this;}
        bignum operator ++ (int)                {return *this+=1,*this-1;}
        bignum operator -- ()                   {return *this-=1,*this;}
        bignum operator -- (int)                {return *this-=1,*this+1;}
        #ifdef _GLIBCXX_CSTRING
        bignum(const char *x)                   {*this=x;}
        bignum operator = (const char *x)       {clear();int len=strlen(x);int rest=len%bit;s.resize((len/bit)+(len%bit!=0));rest+=(!rest)*bit;int CJB=s.size()-1;for(int i=0;i<len;i++){s[CJB]=(s[CJB]<<1)+(s[CJB]<<3)+(x[i]-'0');if(!(--rest))CJB--,rest=bit;}del();return *this;}
        #endif
        #ifdef _GLIBCXX_STRING
        bignum(const string x)                  {*this=x;}
        bignum operator = (const string x)      {clear();int len=x.size( );int rest=len%bit;s.resize((len/bit)+(len%bit!=0));rest+=(!rest)*bit;int CJB=s.size()-1;for(int i=0;i<len;i++){s[CJB]=(s[CJB]<<1)+(s[CJB]<<3)+(x[i]-'0');if(!(--rest))CJB--,rest=bit;}del();return *this;}
        #endif
    };
    bignum operator - (bignum x)        {x.negative^=(!x.zero()); return x;}
    bool operator ! (const bignum &x)   {return x.s[0]==0&&x.s.size()==1;}
    bool operator < (const bignum &x,const bignum &y)   {if(x.negative!=y.negative)return x.negative;if(x.s.size()!=y.s.size()) return (x.s.size()<y.s.size())^x.negative;for(int i=x.s.size()-1;i>=0;i--)if(x.s[i]!=y.s[i])return (x.s[i]<y.s[i])^x.negative;return false;}
    bool operator > (const bignum &x,const bignum &y)   {return y<x;}
    bool operator <= (const bignum &x,const bignum &y)  {return !(y<x);}
    bool operator >= (const bignum &x,const bignum &y)  {return !(x<y);}
    bool operator == (const bignum &x,const bignum &y)  {if(x.negative!=y.negative||x.s.size()!=y.s.size())return false;for(int i=x.s.size()-1;i>=0;i--)if(x.s[i]!=y.s[i])return false;return true;}
    bool operator != (const bignum &x,const bignum &y)  {return !(x==y);}
    static bignum plus(const bignum &x,const bignum &y)
    {
        bignum ANS;
        ANS.s.resize(max(x.s.size(),y.s.size())+1);
        short tag=0;
        for(int i=0;i<ANS.s.size();i++)
        {
            ANS.s[i]=tag;
            if(i<x.s.size()) ANS.s[i]+=x.s[i];
            if(i<y.s.size()) ANS.s[i]+=y.s[i];
            tag=(ANS.s[i]>=bit_pow[bit]);
            ANS.s[i]-=bit_pow[bit]*tag;
        }
        ANS.del();
        return ANS;
    }
    static bignum minus(const bignum &x,const bignum &y)
    {
        bignum ANS;
        ANS.s.resize(max(x.s.size(),y.s.size()));
        short tag=0;
        for(int i=0;i<ANS.s.size();i++)
        {
            ANS.s[i]=tag;
            if(i<x.s.size()) ANS.s[i]+=x.s[i];
            if(i<y.s.size()) ANS.s[i]-=y.s[i];
            tag=-(ANS.s[i]<0);
            ANS.s[i]-=bit_pow[bit]*tag;
        }
        ANS.del();
        return ANS; 
    }
    bignum operator + (const bignum &x,const bignum &y)
    {
        bignum ANS;
        if(x.negative==y.negative)
            ANS=plus(x,y),ANS.negative=x.negative;
        else 
            ANS=minus(max(abs(x),abs(y)),min(abs(x),abs(y))),ANS.negative=(x.negative&&abs(x)>abs(y))||(!x.negative&&abs(y)>abs(x));
        return ANS;
    }
    bignum operator - (const bignum &x,const bignum &y)
    {
        bignum ANS;
        if(x.negative!=y.negative)
            ANS=plus(x,y),ANS.negative=x.negative;
        else 
            ANS=minus(max(abs(x),abs(y)),min(abs(x),abs(y))),ANS.negative=(x.negative&&abs(x)>abs(y))||(!x.negative&&abs(y)>abs(x));
        return ANS;
    }
    bignum operator * (const bignum &x,const bignum &y)
    {
        bignum ANS;
        ANS.s.resize(x.s.size()+y.s.size());
        ANS.negative=x.negative^y.negative;
        for(int i=0;i<ANS.s.size();i++)
            ANS.s[i]=0;
        for(int i=0;i<x.s.size();i++)
        {
            for(int j=0;j<y.s.size();j++)
            {
                ANS.s[i+j]+=x.s[i]*y.s[j];
                ANS.s[i+j+1]+=ANS.s[i+j]/bit_pow[bit];
                ANS.s[i+j]%=bit_pow[bit];
            }
        }
        ANS.del();
        return ANS;
    }
    bignum operator / (const bignum &x,const ll &y)
    {
        bignum ANS;
        ANS.s.resize(x.s.size());
        ANS.negative=(x.negative)^(y<0);
        ll rest=0;
        for(int i=x.s.size()-1;i>=0;i--)
        {
            rest=rest*bit_pow[bit]+x.s[i];
            ANS.s[i]=rest/y;
            rest%=y;
        }
        ANS.del();
        return ANS;
    }
    bignum operator % (const bignum &x,const ll &y)
    {
        ll rest=0;
        for(int i=x.s.size()-1;i>=0;i--)
        {
            rest=rest*bit_pow[bit]+x.s[i];
            rest%=y;
        }
        return x.negative?-rest:rest;
    }
    bignum operator += (bignum &x,const bignum &y)  {return x=x+y;}
    bignum operator -= (bignum &x,const bignum &y)  {return x=x-y;}
    bignum operator *= (bignum &x,const bignum &y)  {return x=x*y;}
    bignum operator /= (bignum &x,const ll &y)      {return x=x/y;}
    bignum operator %= (bignum &x,const ll &y)      {return x=x%y;}
    #ifdef _GLIBCXX_IOSTREAM
    istream& operator >> (istream& in,bignum &x)  {x.input();return in;}
    ostream& operator << (ostream& out,bignum x)  {x.output();return out;}
    #endif
    inline void read(bignum &x)                     {x.input();}
    inline void write(bignum x)                     {x.output();}
    bignum abs(const bignum &x)         {return x.negative?-x:x;}
}
using namespace Bignum;
```