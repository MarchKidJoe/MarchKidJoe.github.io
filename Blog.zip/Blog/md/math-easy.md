## 积性函数

1. 积性函数

    函数 $f(n)$，满足 $f(1) = 1$ 且 $\forall x,y\in N^*$，$\gcd(x,y) = 1$，有 $f(x*y)=f(x)*f(y)$，则 $f(n)$ 为**积性函数**。

    **性质**：

    $$
    f(\prod{p_i^{k_i}})=\prod f({p_i^{k_i}})
    $$

2. 完全积性函数

    函数 $f(n)$，满足 $f(1) = 1$ 且 $\forall x,y\in N^*$，有 $f(x*y)=f(x)*f(y)$，则 $f(n)$ 为**完全积性函数**。

    **性质**：

    $$
    f(\prod{p_i^{k_i}})=\prod f({p_i})^{k_i}
    $$

3. 积性函数的例子

    - **单位函数**(完全积性函数)：$\varepsilon(n)=[n=1]$

    - **恒等函数**(完全积性函数)：$id_k(n)=n^k$

        其中，$id_1(n)$ 记做 $id(n)$。

    - **欧拉函数**: $\varphi(n)=\displaystyle\sum_{i=1}^{n}[\gcd(i,n)=1]$

    - **莫比乌斯函数**:

    $$
    \mu(n)=
    \begin{cases}
    1&n=1\\
    0&\exists d>1,d^2|n\\
    (-1)^{w(n)}&other\\
    \end{cases}
    $$

    其中，$w(n)$ 是与**本质不同**的质因子个数。

## 素数&合数

1. 素数

    正整数 $n$，$n$ 有且只有两个约数，为 $1$ 和 $n$。

2. 合数

    正整数 $n$，$n$ 有约数 $1$ 和 $n$ 以外还有其他约数。

## 数论分块

1. 引入

    对于一个问题，求：

    $$
    \displaystyle\sum_{i=1}^{n}\lfloor\frac{n}{i}\rfloor
    $$

2. 分析

    设 $n=20$，通过~~手算~~：我们发现一段区间的结果是相同的。

    ![](http://marchkidjoe.mygamesonline.org/wp-content/uploads/2022/08/math_easy01.png)

    用我们勤劳的双手和智慧的大脑，再次通过~~手算~~，发现含相同数字的区间的左右端点是这样的：

    ![](http://marchkidjoe.mygamesonline.org/wp-content/uploads/2022/08/math_easy02.png)

3. 结论

    那我们怎么应用上面的区间，避免重复运算呢？主要围绕一个结论：

    对于区间 $l,r$，当 $r=n/(n/l)$ 时，区间 $[l,r]$ 内值是相等的，因此可以用**数论分块**。

    先了解一个理论:

    $$
    \lfloor\frac{\lfloor\frac{n}{a}\rfloor}{b}\rfloor=\lfloor \frac{n}{ab}\rfloor
    \qquad
    \forall n,a,b\in Z
    $$

    要满足 $\lfloor\frac{n}{i}\rfloor=\lfloor\frac{n}{j}\rfloor$，假设 $i,j$ 位于的块左右端点分别为 $l,r$ 那对于左端点为 $l$，此时 $r$ 便为 $\lfloor\frac{n}{\lfloor\frac{n}{l}\rfloor}\rfloor$，在 $[l,r]$ 之间结果相同。

    证明:

    $$
    \because
    \lfloor\frac{n}{i}\rfloor\leqslant \frac{n}{i}
    $$

    $$
    \therefore
    \lfloor \frac{n}{\frac{n}{i}}\rfloor\leqslant\lfloor \frac{n}{\lfloor\frac{n}{i}\rfloor}\rfloor
    $$

    $$
    \because
    \lfloor \frac{n}{\frac{n}{i}}\rfloor=\lfloor i\rfloor=i
    $$

    $$
    \therefore
    i\leqslant\lfloor\frac{n}{\lfloor\frac{n}{i}\rfloor}\rfloor
    $$

    由此证得右端点 $r=\lfloor \frac{n}{\lfloor\frac{n}{i}\rfloor}\rfloor$。

4. Code

    ```cpp
    for (int l = 1, r; l <= n; l = r + 1)
    {
        r = n / (n / l);
        /*do something*/
    }
    ```

## 筛法

### Eratosthenes 筛法（埃氏筛法）

1. 描述

    Eratosthenes 筛法，简单无脑的筛法，具体过程是没筛到一个素数，便把它的整数倍标记，时间复杂度 $O(n\,\log\,\log\,n)$。

2. Code

    ```cpp
    void Eratosthenes(int n)
    {
        vis[1] = true;
        for (int i = 2; i <= n; i++)
        {
            if (!vis[i])
                prime[++cnt] = i;
            for (int j = i * 2; j <= n; j += i)
                vis[j] = true;
        }
    }
    ```

### Euler 筛（线性筛）

1. 描述

    Euler 筛，便是我们常用的筛法，可以在线性复杂度内快速筛出素数，每个合数仅会被它的最小质因子筛一次，时间复杂度 $O(n)$。

2. Code

    ```cpp
    void Euler(int n)
    {
        vis[1] = true;
        for (int i = 2; i <= n; i++)
        {
            if (!vis[i])
                prime[++cnt] = i;
            for (int j = 1; j <= cnt && i * prime[j] <= n; j++)
            {
                vis[i * prime[j]] = true;
                if (i % prime[j] == 0)
                    break;
            }
        }
    }
    ```

## 算术基本定理（唯一分解定理）

1. 内容

    $\forall x\in N^* $，$x$ 可被分解为若干个质数相乘的形式，简而言之，**质因数分解**。

2. 公式

    $$
    \boxed
    {
    x=\displaystyle\prod_{i=1}^{n} p_i^{k_i}
    \qquad
    \forall x\in N^*
    }
    $$

## 裴蜀定理（贝祖定理）

1. 内容

    裴蜀定理全称 $B\text{\'{e}}zout's\,lemma $。$x,y$ 是不全为零的整数，存在整数 $x,y$，使 $ax+by=\gcd(a,b)$ 成立。

2. 公式

    $$
    \boxed
    {
    \exists x_0,y_0,ax_0+by_0=\gcd(a,b)
    \qquad
    \forall x\not=0\lor y\not=0
    }
    $$

## 最大公约数(GCD)

1. 定义

    最大公约数(Greatest Common Divisor)。对于整数 $a,b$ ,若 $n$ 满足 $n\mid a \land n\mid b$ 且 $n$ 为满足条件的最大整数，则称 $n$ 为 $a,b$ 的**最大公约数**，简记为 $\gcd(a,b)$。

    根据**唯一分解定理**，我们可以把 $\gcd(x,y)$ 分解为以下形式：

    $$
    \gcd(x,y)=\displaystyle\prod_{i=1}^{n} p_i^{\min(kx_i,ky_i)}
    $$

    特别的 $\pm1$ 是任意两个整数的公约数。

2. 求取方法

    $(1)$.辗转相除法

    Code

    ```cpp
    template<typename Type>
    Type __gcd(Type m, Type n)
    {
        while (n != 0)
        {
            Type t = m % n;
            m = n;
            n = t;
        }
        return m;
    }
    ```

    $(2)$.更相减损法

    $$
    \boxed
    {
    \gcd(a,b)=\gcd(b,a-b)
    \qquad a\gt b
    }
    $$

    Code

    ```cpp
    template<typename Type>
    Type __gcd(Type m, Type n)
    {
        while (m != n)
        {
            if (m > n) m -= n;
            else n -= m;
        }
        return m;
    }
    ```

    $(3)$.欧几里得算法

    $$
    \boxed
    {
    \gcd(a,b)=\gcd(b,a \bmod b)
    }
    $$

    Code

    ```cpp
    template<typename Type>
    Type __gcd(Type m, Type n)
    {
        return (!n)m:__gcd(n,m%n);
    }
    ```

## 最小公倍数(LCM)

1. 最小公倍数(Least Common Multiple)，对于整数 $a,b$ ,若 $n$ 满足 $a\mid n \land b\mid n$ 且 $n$ 为满足条件的最小整数，则称 $n$ 为 $a,b$ 的**最小公倍数**，简记为 $\operatorname{lcm}(a,b)$。

    根据**唯一分解定理**，我们可以把 $\operatorname{lcm}(x,y)$ 分解为以下形式：

    $$
    \operatorname{lcm}(x,y)=\displaystyle\prod_{i=1}^{n} p_i^{\max(kx_i,ky_i)}
    $$

    特别的 $0$ 是任意两个整数的公倍数。

2. 结论

    $\forall x,y\in N^*$，有 $x\times y=\gcd(x,y)\times\operatorname{lcm}(x,y)$。

    $$
    \boxed
    {
    a\times b=\gcd(a,b)\times\operatorname{lcm}(a,b)
    \qquad
    \forall x,y\in N^*
    }
    $$

3. 证明

    由**唯一分解定理**可得，对于 $\forall x,y\in N^*$，

    $$
    \gcd(x,y)=\displaystyle\prod_{i=1}^{n} p_i^{\min(kx_i,ky_i)}
    $$

    $$
    \operatorname{lcm}(x,y)=\displaystyle\prod_{i=1}^{n} p_i^{\max(kx_i,ky_i)}
    $$

    $$
    x\times y=\displaystyle\prod_{i=1}^{n} p_i^{kx_i+ky_i}
    $$

    综上所述，$x\times y=\gcd(x,y)\times\operatorname{lcm}(x,y)$。

4. 求取方法

    那求法就很~~显然~~了，可以先求出 $\gcd$，再用 $\frac{x\times y}{\gcd}$，得出 $\operatorname{lcm}$。

## 扩展欧几里得算法（EXGCD）

1. 解**同余方程/二元一次不定方程**

    二元一次不定方程：形如以下形式的的方程：

    $$
    ax+by=c
    $$

    同余方程：形如以下形式的的方程：

    $$
    ax\equiv c(\bmod\,p)
    $$

    其实我们可以将同余方程拆为二元一次不定方程的形式：

    $$
    ax+kp=c
    $$

    但我们先研究特殊情况，由裴蜀定理可得，$ax+by=\gcd(a,b)$ 有整数解，拓展欧几里得算法常用于解决**线性方程** $ax+by=\gcd(a,b)$，求出一组可行解。

- 求解过程

    $$
    \begin{cases}
    ax_1+by_1=\gcd(a,b)\\
    bx_2+(a \bmod b)y_2=\gcd(b,a\bmod b)\\
    \end{cases}
    $$

    由欧几里得定理可知：$\gcd(a,b)=\gcd(b,a\bmod b)$

    $$
    \because
    \gcd(a,b)=\gcd(b,a\bmod b)\\
    \therefore
    ax_1+by_1=bx_2+(a\bmod b)y_2\\
    \because
    a \bmod b=a-\lfloor\frac{a}{b}\rfloor\times b\\
    \therefore
    ax_1+by_1=bx_2+(a-\lfloor\frac{a}{b}\rfloor\times b)y_2\\
    \therefore
    ax_1+by_1=ay_2+b(x_2-\lfloor\frac{a}{b}\rfloor y_2)
    $$

    $$
    \begin{cases}
    x_1=y_2\\
    y_1=x_2-\lfloor\frac{a}{b}\rfloor y_2\\
    \end{cases}
    $$

    那 $x_2,y_2$ 即为递归回溯时返回的值，于是可以由以下代码实现：

    ```cpp
        Type temp = x;
        x = y;
        y = temp - (a / b) * y;
    ```

    考虑边界问题：对于函数 $\gcd(a,b)$，递归边界为 $b=0$，此时 $\gcd=a$，那此时方程变为 $ax+0=a$，得出解为 $x=1,y=0$，当然 $y$ 是一般情况下设为 $0$。随后在回溯过程中解出 $x,y$ 的特解。

    Code

    ```cpp
    template <typename Type> Type exgcd(Type a, Type b, Type &x, Type &y)
    {
        /*Warning:x,y记得加引用&*/
        if (b == 0)
        {
            x = 1;
            y = 0;
            return a;
        }
        Type gcd = exgcd(b, a % b, y, x);
        y -= (a / b) * x; /*巧妙运用引用&*/
        /*等效于
            Type temp = x;
            x = y;
            y = temp - (a / b) * y;
        */
        return gcd;
    }
    ```

    现在求出了特解 $x_0,y_0$，那要是题目问最小正整数解怎么办呢？来看通解：

    $$
    \begin{cases}
    x=x_0+k\frac{b}{\gcd(a,b)}\\
    y=y_0-k\frac{a}{\gcd(a,b)}\\
    \end{cases}
    $$

    其中 $k\in Z$。

    证明：

    $$
    ax_0+by_0=\gcd(a,b)
    $$

    $$
    a(x_0-bd)+b(y_0+ad)=\gcd(a,b)
    $$

    要是 $bd,ad\in Z$，那 $d$ 的最小值只能等于 $\frac{1}{\gcd(a,b)}$。

    于是代入可得通解。

    证毕。

2. 求**逆元**

    这个问题放到了**逆元**板块，先简单了解有这么个用途。

3. 求**gcd(a,b)**

    ~~废话~~。

4. [【模板】裴蜀定理](https://www.luogu.com.cn/problem/P4549)

## 欧拉定理

1. 欧拉定理

    对于任意正整数 $a,p$，且 $a,p$ 互质，都有 $a^{\varphi(a)}\equiv1(\bmod\,p)$，其中 $\varphi(a)$ 为**欧拉函数**。

    $$
    \boxed
    {
    a^{\varphi(a)}\equiv1(\bmod\,p)
    \qquad
    \forall a,p\in N^{*} \land \gcd(a,p)=1
    }
    $$

2. 拓展欧拉定理

    拓展欧拉定理主要应用于**降幂**计算，具体内容如下：

    $$
    a^b\equiv
    \begin{cases}
    a^{b\,\bmod\varphi(m)}
    &\gcd(a,m)=1\\
    a^b
    &\gcd(a,m)\not=1,b<\varphi(m),(\bmod m)\\
    a^{(b\,\bmod\varphi(m))+\varphi(m)}
    &\gcd(a,m)\not=1,b\geqslant\varphi(m)
    \end{cases}
    $$

## 费马小定理

1. 定理

    对于任意质数 $p$，都有 $a^{p-1}\equiv1(\bmod\,p)$。

    $$
    \boxed
    {
    a^{p-1}\equiv1(\bmod\,p)
    \qquad
    \forall p\in prime
    }
    $$

2. 证明：

    可以用欧拉定理证明，因为对于质数 $p$，$\varphi(p)=p-1$，代入欧拉定理即可得出。

    PS:（以上定理具体证明由于 MarchKidJoe 不够**巨**，没有研究，若有兴趣可自行参考其他资料。）

## 逆元(INV)

1. 逆元(inv)

    先解释定义以及为什么有逆元 (~~为了考你~~)。已知 $(a\times b)\bmod p=(a\bmod p)\times(b\bmod p)$，但是除法却不满足这一性质 $(a/b)\bmod p\not=(a\bmod p)/(b\bmod p)$。于是除法取余该怎么办呢？就产生了逆元。逆元，就是一个数 $x$，$x^{-1}$ 在 $\bmod\,p$ 意义下的值。

    但首先你要牢记：**两个不互质的数之间没有逆元**。

    $$
    \boxed
    {
    x\times x^{-1}\equiv1(\bmod\,p)
    \qquad
    \gcd(x,p)=1
    }
    $$

    $x^{-1}$ 即为**逆元**。

2. 求单个逆元

    $(1)$.扩展欧几里得算法(exgcd)

    **使用条件: $\gcd(i,p)=1$**

    可以发现，这就是**裴蜀定理**，用**扩展欧几里得算法**解出特解，$i^{-1}$ 对应 $ax+by=\gcd(a,b)$ 中的 $x_0$，$x_0$ 即为 $i$ 在模 $p$ 意义下的**逆元**。

    Code

    ```cpp
    Type exgcd(Type a, Type b, Type &x, Type &y)
    {
        if (b == 0)
        {
            x = 1;
            y = 0;
            return a;
        }
        Type gcd = exgcd(b, a % b, y, x);
        y -= (a / b) * x;
        return gcd;
    }
    Type get_inv(Type m, Type mod)
    {
        Type x, y;
        Type gcd = exgcd(m, mod, x, y);
        return (x % mod + mod) % mod;
    }
    ```

    $(2)$.快速幂(quick_pow)

    **使用条件：$p\in prime$**

    由**费马小定理**可得：对于质数 $p$，$a^{p-1}\equiv1(\bmod\,p)$。

    化式子：

    $$
    i\times i^{-1}=1+k\times p
    \qquad
    (k\in Z)\\
    i\times i^{-1}-k\times p=1\\
    \because
    \gcd(i,p)=1\\
    \therefore
    i\times i^{-1}-k\times p=\gcd(i,p)\\
    $$

    可以发现，$i^{p-2}(\bmod\,p)$ 即为 $i$ 在模 $p$ 意义下的**逆元**。

    Code

    ```cpp
    Type quick_pow(Type x, Type y, Type mod)
    {
        Type ans = 1;
        while (y > 0)
        {
            if (y & 1 == 1)
                ans = ans * x % mod;
            x = x * x % mod;
            y >>= 1;
        }
        return ans;
    }
    Type get_inv(Type x, Type mod)
    {
        return quick_pow(x, mod - 2, mod);
    }
    ```

3. 线性求出区间逆元

    (1).求在模 $p$ 意义下的一段连续区间 $[1,n]$ 的逆元。

    可以先求出 $inv_a$，然后用公式：

    $$
    inv_i=(p-\lfloor \frac{p}{i} \rfloor)\times inv_{p \bmod i}
    \qquad
    (\bmod\,p)
    $$

    Code

    ```cpp
    inv[1] = 1;
    for (int i = 2; i <= n; i++)
        inv[i] = (p - p / i) * inv[p % i] % p;
    ```

    (2).求在模 $p$ 意义下的一段连续的阶乘逆元

    这个广泛用于求组合数 $C_n^m$。一般会用到阶乘的逆元，此时就需要预处理，所以可以先求出较大数的阶乘的逆元(较大数不能为 $p$，$p\equiv0(\bmod\,p)$ )，有结论如下：

    $$
    inv_i=inv_{i+1}\times(i+1)
    \qquad
    (\bmod\,p)
    $$

    Code

    ```cpp
    fac[0] = 1;
    inv[0] = 1;
    for (int i = 1; i <= p; i++)
        fac[i] = fac[i - 1] * i % p;
    inv[p - 1] = quick_pow(fac[p - 1], p - 2, p);
    for (int i = p - 2; i >= 1; i--)
        inv[i] = inv[i + 1] * (i + 1) % p;
    ```

4. [【模板】乘法逆元](https://www.luogu.com.cn/problem/P3811)

## 中国剩余定理(CRT)

有这样一个问题：$5$ 个人一行多 $2$ 人，$3$ 个人一行多 $1$ 人，$7$ 个人一行多 $4$ 人。问：最少有多少人？
（~~小学奥数？~~）

1. 介绍

    中国剩余定理(Chinese Remainder Theorem, CRT)，可用于求解形式如下的方程组：

    $$
    \begin{cases}
    x&\equiv r_1(\bmod\,m_1)\\
    x&\equiv r_2(\bmod\,m_2)\\
    &\vdots\\
    x&\equiv r_n(\bmod\,m_n)\\
    \end{cases}
    $$

    上面的问题便可以解决了。

2. 算法流程

    首先先点明这个算法的适用条件：$\forall i\not =j,\gcd(m_i,m_j)=1$。即模数**两两互质**。

    $(1)$.计算所有的模数乘积 $M$：

    $$
    M=\displaystyle\prod_{i=1}^{n}m_i
    $$

    $(2)$.计算 $s_i$ 数组：

    $$
    s_i=\frac{M}{m_i}
    $$

    $(3)$.计算 $inv_i$ 数组：

    $$
    inv_i={s_i}^{-1}(\bmod\,m_i)
    $$

    $(4)$.解出 $Ans$：

    $$
    Ans=\displaystyle\sum_{i=1}^{n}inv_is_ir_i(\bmod\,M)
    $$

3. 算法证明

    我们只需要证明 $Ans$ 对于任意一个方程都成立就可以了。

    $\forall i\not=j$，都有 $s_j\equiv0(\bmod\,m_i)$。原因很简单，因为 $s_i$ 是除了 $m_i$ 以外所有模数的乘积，所以 $s_j$ 内一定还有 $m_i$ 这个模数，所以 $s_j\equiv 0(\bmod\,m_i)$。

    又因为 $s_iinv_i\equiv1(\bmod\,m_i)$，所以 $s_iinv_ir_i\equiv r_i(\bmod\,m_i)$。

    就有了对于任意模数 $m_i$ 都成立的式子：

    $$
    \begin{aligned}
    Ans
    &=\displaystyle\sum_{i=1}^{n}inv_is_ir_i
    &(\bmod\,m_i)\\
    &={s_i}^{-1}s_ir_i
    &(\bmod\,m_i)\\
    &=r_i
    &(\bmod\,m_i)
    \end{aligned}
    $$

    证毕。

4. Code

    ```cpp
    #include <bits/stdc++.h>
    #define SIZE (10 + 5)
    #define ll long long
    using namespace std;
    ll m[SIZE];
    ll r[SIZE];
    ll s[SIZE];
    ll inv[SIZE];
    void exgcd(ll a, ll b, ll &x, ll &y)
    {
        if (b == 0)
        {
            x = 1;
            y = 0;
            return;
        }
        exgcd(b, a % b, y, x);
        y -= (a / b) * x;
    }
    ll get_inv(ll m, ll mod)
    {
        ll x, y;
        exgcd(m, mod, x, y);
        return (x % mod + mod) % mod;
    }
    int main()
    {
        int n;
        ll M = 1, ans = 0;
        scanf("%d", &n);
        for (int i = 1; i <= n; i++)
            scanf("%lld%lld", &m[i], &r[i]);
        for (int i = 1; i <= n; i++)
            M *= m[i];
        for (int i = 1; i <= n; i++)
            s[i] = M / m[i];
        for (int i = 1; i <= n; i++)
            inv[i] = get_inv(s[i], m[i]);
        for (int i = 1; i <= n; i++)
            ans = (ans % M + inv[i] % M * s[i] % M * r[i] % M) % M;
        printf("%lld", ans);
        return 0;
    }
    ```

5. [【模板】中国剩余定理（CRT）](https://www.luogu.com.cn/problem/P1495)

## 威尔逊定理(Wilson)

1. 定理

    $$
    \boxed
    {
    (p-1)!\equiv-1
    \qquad
    (\bmod\,p)
    \qquad
    \forall p\in prime
    }
    $$

2. 文献

    如果想了解更多可以**Go To OIWIKI**。

    Click [here](https://oi-wiki.org/math/number-theory/wilson/)

## 卢卡斯定理(Lucas)

1. 引入

    求解

    $$
    C_{n}^{m}\bmod p
    \qquad
    p\in prime
    $$

2. 结论

    $$
    \boxed
    {
    C_n^m(\bmod\,p)=C_{n/p}^{m/p}\times C_{n\bmod\,p}^{m\bmod\,p}(\bmod\,p)
    }
    $$

    观察这个式子，我们可以发现 $C_{n/p}^{m/p}$ 可以递归求解，$C_{n\bmod\,p}^{m\bmod\,p}$ 可以预处理出来，就要用到**线性求阶乘逆元**这个算法了。

3. Code

    ```cpp
    #include <bits/stdc++.h>
    #define SIZE (100000 + 10)
    #define ll long long
    using namespace std;
    ll fac[SIZE];
    ll inv[SIZE];
    ll quick_pow(ll x, ll y, ll mod)
    {
        ll ans = 1;
        while (y > 0)
        {
            if (y & 1)
                ans = ans * x % mod;
            x = x * x % mod;
            y >>= 1;
        }
        return ans % mod;
    }
    void init(int p)
    {
        fac[0] = inv[0] = 1;
        for (int i = 1; i <= p; i++)
            fac[i] = fac[i - 1] * i % p;
        inv[p - 1] = quick_pow(fac[p - 1], p - 2, p);
        for (int i = p - 2; i >= 1; i--)
            inv[i] = inv[i + 1] * (i + 1) % p;
    }
    ll C(ll n, ll m, ll p)
    {
        if (m > n)
            return 0;
        return fac[n] % p * inv[n - m] % p * inv[m] % p;
    }
    ll lucas(ll n, ll m, ll p)
    {
        if (!m)
            return 1;
        return lucas(n / p, m / p, p) * C(n % p, m % p, p) % p;
    }
    int main()
    {
        int n, m, p;
        scanf("%d %d %d", &n, &m, &p);
        init(p);
        printf("%lld", lucas(n, m, p));
        return 0;
    }
    ```

4. [ 【模板】卢卡斯定理（Lucas）](https://www.luogu.com.cn/problem/P3807)

关于Lucas具体证明，可以参考其他文献。

## 大步小步算法(BSGS)

BSGS(baby-Step giant-step)，又称大步小步算法。

1. 引入

    给定一个方程，求 $x$ 最小正整数解。

    $$
    a^x\equiv b
    \qquad
    (\bmod\,p)
    \qquad
    p\in prime
    $$

2. 算法流程

    $(1)$.设 $t\in[0,\lceil\sqrt p\rceil]$ 先将式子化为:

    $$
    a^{k\lceil\sqrt p\rceil-t}\equiv b
    \qquad
    (\bmod\,p)
    $$

    $$
    a^{k\lceil\sqrt p\rceil}\equiv a^tb
    \qquad
    (\bmod\,p)
    $$

    $(2)$.预处理：对于这个式子，我们就可以先预处理出来 $a^tb(\bmod\,p)$，然后再枚举 $a^{k\lceil\sqrt p\rceil}(\bmod\,p)$，并判断 $a^tb(\bmod\,p)$ 是否存在（可以用 map,hash ）。

    $(3)$.得出答案为 $k\times\lceil\sqrt p\rceil-t$。

3. Code

    ```cpp
    #include <bits/stdc++.h>
    #define ll long long
    using namespace std;
    map<ll, vector<int>> s;
    ll quick_pow(ll x, ll y, ll mod)
    {
        ll ans = 1;
        while (y > 0)
        {
            if (y & 1 == 1)
                ans = ans * x % mod;
            x = x * x % mod;
            y >>= 1;
        }
        return ans % mod;
    }
    int main()
    {
        ll p, a, b;
        scanf("%lld%lld%lld", &p, &a, &b);
        a %= p;
        b %= p;
        if (b == 0)
            b += p;
        ll sqr = ceil(sqrt(p));
        for (int i = 0; i <= sqr; i++, b = b * a % p)
            s[b].push_back(i);
        ll k = quick_pow(a, sqr, p);
        ll mul = 1 % p;
        for (int i = 0; i <= sqr; i++, mul = mul * k % p)
            if (s.count(mul))
                for (int j = s[mul].size() - 1; j >= 0; j--)
                    if (sqr * i - s[mul][j] >= 0)
                    {
                        printf("%d", sqr * i - s[mul][j]);
                        return 0;
                    }
        printf("no solution");
        return 0;
    }
    ```

4. [【模板】BSGS](https://www.luogu.com.cn/problem/P3846)

    **代码细节**：

    BSGS 坑很多，我使用 map 套 vector 是为了防止出现 $i$ 不同但 $b\times a^i(\bmod\,p)$ 相同导致数据覆盖。

    **其他细节**：

    - 预处理循环范围 $[0,\lceil\sqrt p\rceil]$。

    - 枚举循环范围 $[0,\lceil\sqrt p\rceil]$。

    - 判断答案 $i\times\lceil\sqrt p\rceil-t$ 是否为**非负整数**，若都不成立则无解。

    - 可以先对 $a,b$ 取模，但最好保证 $b\not=0$。

    - 对 $a^0=1$ 也要取模，总有~~毒瘤~~数据（尽管 $1$ 不是质数） $p=1$。