包含NTT INV LN EXP SQRT。

---

```cpp
#include<cstdio>
#include<vector>
using namespace std;
namespace polynomial
{
    namespace IO
    {
        template <typename Type> void read(Type &n)
        {
            Type w=1;char x=getchar();n=0;
            while(x<'0'||x>'9'){if(x=='-')w=-1;x=getchar();}
            while(x>='0'&&x<='9'){n=(n<<1)+(n<<3)+(x^48);x=getchar();}
            n*=w;
        }
        template <typename Type,typename...Etc> void read(Type &n,Etc &...etcs)
        {
            read(n);read(etcs...);
        }
        template <typename Type> void write(Type x)
        {
            if(x<0) putchar('-'),x=-x;
            if(x>9) write(x/10);
            putchar(x%10+'0');
        }
    }
    using namespace IO;
    typedef long long ll;
    const int mod=998244353;
    const int g=3;
    const int ginv=332748118;
    int relength(int x)
    {
        int length=1;
        while(length<=x) length<<=1;
        return length;
    }
    int ksm(int x,int y)
    {
        int ans=1;
        while(y>0){if(y&1)ans=(ll)ans*x%mod;x=1ll*x*x%mod;y>>=1;}
        return ans;
    }
    void rev(vector<int> &A,int length)
    {
        for(int i=1,j=length>>1;i<length-1;i++)
        {
            if(i<j) swap(A[i],A[j]);
            int k=length>>1;
            while(j>=k)j-=k,k>>=1;
            j|=k;
        }
    }
    void NTT(vector<int>&,int,int);
    void NTT_LN(vector<int>,vector<int>&,int,int);
    void NTT_INV(vector<int>&,vector<int>&,int);
    void NTT_INV(vector<int>,vector<int>&,int,int);
    void NTT_EXP(vector<int>&,vector<int>&,int);
    void NTT_EXP(vector<int>,vector<int>&,int,int);
    void NTT_SQRT(vector<int>&,vector<int>&,int);
    void NTT_SQRT(vector<int>,vector<int>&,int,int);
    vector <int> H,L;
    struct ntt
    {
        vector<int> s;
        ntt()                            {s.clear();}
        void clear()                    {s.clear();}
        void input(int n)                {for(int i=0,x;i<=n;i++) read(x),s.push_back(x);}
        void output()                    {for(int i=0;i<s.size();i++) write(s[i]),putchar(' ');}
        int size()                        {return s.size();}
        int length()                    {return s.size()-1;}
        vector<int>vec()                {return s;}
        int& operator [] (int x)        {return s[x];}
        ntt operator = (vector<int>&x)    {return s=x,*this;}
        ntt (vector<int>&x)                {*this=x;}
        friend ntt operator * (ntt A,ntt B)
        {
            int sum=A.length()+B.length();
            int length=relength(A.size()+B.size());
            int linv=ksm(length,mod-2);
            A.s.resize(length);B.s.resize(length);
            NTT(A.s,length,1);NTT(B.s,length,1);
            for(int i=0;i<length;i++)
                A.s[i]=(1ll*A.s[i]*B.s[i]%mod*linv)%mod;
            NTT(A.s,length,-1);
            while(A.length()>sum) A.s.pop_back();
            return A;
        }
        ntt Differential()
        {
            ntt ANS; ANS.s.resize(size());
            for(int i=1;i<size();i++) ANS.s[i-1]=1ll*i*s[i]%mod;
            ANS[size()-1]=0;
            return ANS;
        }
        ntt Integral()
        {
            ntt ANS; ANS.s.resize(size());
            for(int i=1;i<size();i++) ANS.s[i]=1ll*s[i-1]*ksm(i,mod-2)%mod;
            ANS[0]=0;
            return ANS;
        }
        ntt inv()
        {
            int length=relength(size())<<1; H.resize(length);
            ntt ANS; ANS.s.resize(length);
            NTT_INV(s,ANS.s,size());
            while(ANS.length()>=size()) ANS.s.pop_back();
            return ANS;
        }
        ntt exp()
        {
            int length=relength(size())<<1; H.resize(length);
            ntt ANS; ANS.s.resize(length);
            NTT_EXP(s,ANS.s,size());
            while(ANS.length()>=size()) ANS.s.pop_back();
            return ANS;
        }
        ntt sqrt()
        {
            int length=relength(size())<<1; H.resize(length);
            ntt ANS; ANS.s.resize(length);
            NTT_SQRT(s,ANS.s,size());
            while(ANS.length()>=size()) ANS.s.pop_back();
            return ANS;
        }
        ntt ln()
        {
            ntt ANS=(inv()*Differential()).Integral();
            while(ANS.length()>=size()) ANS.s.pop_back();
            return ANS;
        }
    };
    void NTT(vector<int> &A,int length,int opt)
    {
        rev(A,length);
        for(int i=1;i<length;i<<=1)
        {
            ll wn=ksm(opt==1?g:ginv,(mod-1)/(i<<1));
            for(int j=0;j<length;j+=(i<<1))
            {
                ll w=1;
                for(int k=j;k<j+i;k++,w=w*wn%mod)
                {
                    int x=A[k];
                    int y=w*A[k+i]%mod;
                    A[k]=(x+y)%mod;
                    A[k+i]=(x-y+mod)%mod;
                }
            }
        }
    }
    void NTT_LN(vector<int> A,vector<int> &LN,int length,int limit)
    {
        while(A.size()>length+1) A.pop_back();
        LN=((ntt)(A)).ln().vec();
        LN.resize(limit);
    }
    void NTT_INV(vector<int> A,vector<int> &INV,int length,int limit)
    {
        while(A.size()>length+1) A.pop_back();
        INV=((ntt)(A)).inv().vec();
        INV.resize(limit);
    }
    void NTT_EXP(vector<int> A,vector<int> &EXP,int length,int limit)
    {
        while(A.size()>length+1) A.pop_back();
        EXP=((ntt)(A)).exp().vec();
        EXP.resize(limit);
    }
    void NTT_SQRT(vector<int> A,vector<int> &SQRT,int length,int limit)
    {
        while(A.size()>length+1) A.pop_back();
        SQRT=((ntt)(A)).sqrt().vec();
        SQRT.resize(limit);
    }
    void NTT_INV(vector<int> &A,vector<int> &INV,int length)
    {
        if(length==1) return void(INV[0]=ksm(A[0],mod-2));
        NTT_INV(A,INV,(length+1)>>1);
        int limit=relength(length<<1);
        int linv=ksm(limit,mod-2);
        for(int i=0;i<length;i++) H[i]=A[i];
        for(int i=length;i<limit;i++) H[i]=0;
        NTT(H,limit,1); NTT(INV,limit,1);
        for(int i=0;i<limit;i++)
            INV[i]=(1ll*INV[i]*(2-1ll*H[i]*INV[i]%mod+mod)%mod)*linv%mod;
        NTT(INV,limit,-1);
        for(int i=length;i<limit;i++) INV[i]=0;
    }
    void NTT_EXP(vector<int> &A,vector<int> &EXP,int length)
    {
        if(length==1) return void(EXP[0]=1);
        NTT_EXP(A,EXP,(length+1)>>1);
        int limit=relength(length<<1);
        int linv=ksm(limit,mod-2);
        NTT_LN(EXP,L,length,limit);
        for(int i=0;i<length;i++) H[i]=A[i];H[0]=1;
        for(int i=length;i<limit;i++) H[i]=L[i]=0;
        for(int i=0;i<limit;i++) H[i]=((H[i]-L[i])%mod+mod)%mod;
        NTT(H,limit,1); NTT(EXP,limit,1);
        for(int i=0;i<limit;i++)
            EXP[i]=(1ll*EXP[i]*H[i]%mod*linv)%mod;
        NTT(EXP,limit,-1);
        for(int i=length;i<limit;i++) EXP[i]=0;
    }
    void NTT_SQRT(vector<int> &A,vector<int> &SQRT,int length)
    {
        if(length==1) return void(SQRT[0]=1);
        NTT_SQRT(A,SQRT,(length+1)>>1);
        int limit=relength(length<<1);
        int linv=ksm(limit,mod-2);
        NTT_INV(SQRT,L,length,limit);
        ll inv2=ksm(2,mod-2);
        for(int i=0;i<length;i++) H[i]=A[i];
        for(int i=length;i<limit;i++) H[i]=L[i]=0;
        NTT(H,limit,1); NTT(SQRT,limit,1); NTT(L,limit,1);
        for(int i=0;i<limit;i++)
            SQRT[i]=1ll*(H[i]+1ll*SQRT[i]*SQRT[i]%mod)%mod*L[i]%mod*linv%mod*inv2%mod;
        NTT(SQRT,limit,-1);
        for(int i=length;i<limit;i++) SQRT[i]=0;
    }
}
using namespace polynomial;
ntt A,B;
signed main()
{
    int n,m;
    read(n);
    A.input(--n);
    A.inv().output();putchar('\n');
    A.ln().output();putchar('\n');
    A.exp().output();putchar('\n');
    A.sqrt().output();putchar('\n');
    (A*B).output();
    return 0;
}
```