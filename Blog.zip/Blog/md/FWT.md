## FWT

**快速沃尔什变换** (FWT) 不同于**快速傅里叶变换** (FFT) 和**快速数论变换** (NTT)。

普通卷积类型的多项式：$F=A*B$。一般用 FFT 和 NTT 解决。

$$
F_x=\displaystyle\sum_{i+j=x}A_i\times B_j
$$

特殊卷积类型的多项式：$F=A*B$。可以用 FWT 解决，其中 $\oplus$ 为**二进制运算**。

$$
F_x=\displaystyle\sum_{i\oplus j=x}A_i\times B_j
$$

## 定义

$F$：整个多项式 $F$。

$F_x$：多项式 $F$ 的第 $x$ 项的**系数**。特殊的：$F_0,F_1$ 表示左半多项式和右半多项式，具体含义文章会解释。

$F+G$：多项式 $F$ 和 $G$ 对应系数相加。

$i\supset j$：二进制状态下 $i$ 中的 $1$ 的位置是 $j$ 的 $1$ 的位置的**子集**。

$\operatorname{popcount}(x)$：$x$ 在二进制表示下 $1$ 的个数。

$\text{or}$：或运算。

$\text{and}$：与运算。

$\text{xor}$：异或运算。

$\text{xnor}$：同或运算。

$n$：经典多项式，保证 $n=2^k-1$。

## 或运算

### 卷积公式

$$
F_x=\displaystyle\sum_{(i \text{ or }j)=x}A_i\times B_j
$$

### 正变换

定义多项式 $F$ 的或运算的**沃尔什正变换**为：

$$
\begin{aligned}
\operatorname{FWT}(F)
_i
&=\displaystyle\sum_{j=0}^{n} F_j[(i\text{ or }j)=i]\\
&=\displaystyle\sum_{j\supset i}^{n} F_j
\end{aligned}
$$

考虑改如何变换。

方法 1：

直接套式子，时间复杂度 $O(n^2)$，原地去世。

方法 2：

分治，时间复杂度 $O(n\log n)$。正确的，一针见血的。

设多项式为 $F$  共 $2^k$ 项，将**项数**拆为平均分为两部分，左右部分的区间各自含有 $2^{k-1}$ 项，左区间记作 $F_0$，右区间记作 $F_1$，这里的 $F_0,F_1$  指的是左半和右半多项式。

---

PS：我并不认同网上大部分人的看法，说左半部分最大项数二进制为 $0$，右半部分最大项数为 $1$，显然不对，但是对于**或运算**来说右半区间包含左半区间的贡献肯定是正确的，如图：

![](https://cdn.luogu.com.cn/upload/image_hosting/t78akftx.png)

虽然二分 $[0,7]$ 区间成立，但是比如二分 $[4,7]$ 区间，但是最高位都是 $1$，非常尴尬。不如直接说右半区间包含左半区间的贡献。

---

然后我们可以得到：

$F'_0\implies F_0,F'_1\implies F_0+F_1$。

从二进制的角度理解，貌似 $1$ 更多一点：

$$
\begin{aligned}
0=0{\text{ or }}0\\
1=0{\text{ or }}1\\
1=1{\text{ or }}0\\
1=1{\text{ or }}1\\
\end{aligned}
$$

感性理解：$1$ 的贡献一定要包含 $0$ 的贡献，所以转移更新的式子：

$$
\operatorname{FWT}(F)=\operatorname{replace}(\operatorname{FWT}(F_0),\operatorname{FWT}(F_0+F_1))
$$

个人觉得 $\operatorname{replace}$ 好理解，$\operatorname{replace}$ 就是对应位置的权值被替换为相应的权值。

形象地解释上面的式子的 $\operatorname{replace}$，反映到代码上就是：$F_0=F_0;F_1=F_0+F_1;$

这张图（图片来源于[巨佬博客](https://www.cnblogs.com/wyb-sen/p/15779952.html)），能很好地描述 FWT：

![](https://cdn.luogu.com.cn/upload/image_hosting/eyhryrw0.png)

一种颜色代表当前这一层的处理方式，每个箭头起点的贡献累加到终点的贡献，恰好是子集和。

### 卷积

卷积时间复杂度 $O(n)$，处理完了 $\operatorname{FWT}(A),\operatorname{FWT}(B)$。现在要证明：

$$
\operatorname{FWT}(A)*\operatorname{FWT}(B)=\operatorname{FWT}(F)
$$

那现在证明任意一项：

$$
\begin{aligned}
\operatorname{FWT}(F)_k
&=\displaystyle\sum_{s\supset k}^{n} F_s\\
&=\displaystyle\sum_{s\supset k}^{n}\displaystyle\sum_{(i\text{ or }j)=s} A_i\times B_j\\
&=\displaystyle\sum_{(i\text{ or }j)\supset k}^{n} A_i\times B_j\\
&=\displaystyle\sum_{i\supset k}^{n} A_i\times \displaystyle\sum_{j\supset k}^{n}B_j\\
&=\operatorname{FWT} (A)_k*\operatorname{FWT} (B)_k
\end{aligned}
$$

### 逆变换

多项式 $F$ 的**沃尔什逆变换**为点值变换为系数。

简单的理解为：既然正变换 FWT 时 $F_1$ 加上了 $F_0$ 的贡献，逆变换减回去就行了：

$$
\operatorname{IFWT}(F)=\operatorname{replace}(\operatorname{IFWT}(F_0),\operatorname{IFWT}(F_0-F_1))
$$

经过了正变换，已经求出来了 $\operatorname{FWT}(A)$，所以也就已知了 $\operatorname{FWT}(A)_0,\operatorname{FWT}(A)_1$。
首先区分

$\operatorname{FWT}(A)_0$：多项式 $\operatorname{FWT}(A)$ 的左半区间。

$\operatorname{FWT}(A_0)$：正变换多项式左半区间 $A_0$ 得到的多项式。

$\operatorname{FWT}(A)_1$：多项式 $\operatorname{FWT}(A)$ 的右半区间。

$\operatorname{FWT}(A_1)$：正变换多项式右半区间 $A_0$ 得到的多项式。

证明：

$$
\begin{aligned}
\operatorname{FWT}(A)_0
&=\operatorname{FWT}(A_0)\\
\operatorname{FWT}(A_0)
&=\operatorname{FWT}(A)_0\\\\
\operatorname{FWT}(A)_1
&=\operatorname{FWT}(A_0)+\operatorname{FWT}(A_1)\\
\operatorname{FWT}(A_1)
&=\operatorname{FWT}(A)_1-\operatorname{FWT}(A_0)\\
&=\operatorname{FWT}(A)_1-\operatorname{FWT}(A)_0\\\\
A_0
&=\operatorname{IFWT}(\operatorname{FWT}(A_0))\\
&=\operatorname{IFWT}(\operatorname{FWT}(A)_0)\\\\
A_1
&=\operatorname{IFWT}(\operatorname{FWT}(A_1))\\
&=\operatorname{IFWT}(\operatorname{FWT}(A)_1-\operatorname{FWT}(A)_0)\\\\
\end{aligned}
$$

### Code

```cpp
void FWT_OR(int *A)
{
    for (int i = 1; i < length; i <<= 1)
    {
        for (int j = 0; j < length; j += (i << 1))
        {
            for (int k = j; k < j + i; k++)
            {
                A[k] = A[k];
                A[k + i] = A[k + i] + A[k];
            }
        }
    }
}
void IFWT_OR(int *A)
{
    for (int i = 1; i < length; i <<= 1)
    {
        for (int j = 0; j < length; j += (i << 1))
        {
            for (int k = j; k < j + i; k++)
            {
                A[k] = A[k];
                A[k + i] = A[k + i] - A[k];
            }
        }
    }
}
```

或者直接写成一个函数：

```cpp
void FWT_OR(int *A, int opt) /*opt={-1,+1}*/
{
    for (int i = 1; i < length; i <<= 1)
    {
        for (int j = 0; j < length; j += (i << 1))
        {
            for (int k = j; k < j + i; k++)
            {
                A[k + i] = A[k + i] + opt * A[k];
            }
        }
    }
}
```

## 与运算

### 卷积公式

$$
F(x)=\displaystyle\sum_{(i \text{ and }j)=x}A(i)\times B(j)
$$

### 正变换

定义多项式 $F$ 的与运算的**沃尔什正变换**为：

$$
\begin{aligned}
\operatorname{FWT}(F)_i
&=\displaystyle\sum_{j=0}^{n} F_j[(i\text{ and }j)=i]\\
&=\displaystyle\sum_{i\supset j}^{n} F_j
\end{aligned}
$$

变换类比或运算，还是分治，时间复杂度 $O(n\log n)$。

设多项式为 $F$  共 $2^k$ 项，将**项数**拆为平均分为两部分，左右部分的区间各自含有 $2^{k-1}$ 个，左区间记作 $F_0$，右区间记作 $F_1$。

然后我们可以得到：

$F'_0\implies F_0+F_1,F'_1\implies F_1$。

从二进制角度理解：

$$
\begin{aligned}
0=0{\text{ and }}0\\
0=0{\text{ and }}1\\
0=1{\text{ and }}0\\
1=1{\text{ and }}1\\
\end{aligned}
$$

所以恰好和或运算相反，由此得到转移更新的式子：

$$
\operatorname{FWT}(F)=\operatorname{replace}(\operatorname{FWT}(F_0+F_1),\operatorname{FWT}(F_1))
$$

关于那张图，把箭头反过来就好了：

![](https://cdn.luogu.com.cn/upload/image_hosting/121gthfn.png)

### 卷积

卷积时间复杂度 $O(n)$，处理完了 $\operatorname{FWT}(A),\operatorname{FWT}(B)$。现在要证明：

$$
\operatorname{FWT}(A)*\operatorname{FWT}(B)=\operatorname{FWT}(F)
$$

那现在证明任意一项，其实和或运算基本一样：

$$
\begin{aligned}
\operatorname{FWT} (F)_k
&=\displaystyle\sum_{k\supset s}^{n} F_s\\
&=\displaystyle\sum_{k\supset s}^{n}\displaystyle\sum_{(i\text{ and }j)=s} A_i\times B_j\\
&=\displaystyle\sum_{k\supset (i\text{ and }j)}^{n} A_i\times B_j\\
&=\displaystyle\sum_{k\supset i}^{n} A_i\times \displaystyle\sum_{k\supset j}^{n}B_j\\
&=\operatorname{FWT} (A)_k*\operatorname{FWT} (B)_k
\end{aligned}
$$

### 逆变换

多项式 $F$ 的**沃尔什逆变换**为点值变换为系数。

简单的理解为：既然正变换 FWT 时 $F_0$ 加上了 $F_1$ 的贡献，逆变换减回去就行了：

$$
\operatorname{IFWT}(F)=\operatorname{replace}(\operatorname{IFWT}(F_0-F_1),\operatorname{IFWT}(F_1))
$$

证明：

$$
\begin{aligned}
\operatorname{FWT}(A)_1
&=\operatorname{FWT}(A_1)\\
\operatorname{FWT}(A_1)
&=\operatorname{FWT}(A)_1\\\\
\operatorname{FWT}(A)_0
&=\operatorname{FWT}(A_0)+\operatorname{FWT}(A_1)\\
\operatorname{FWT}(A_0)
&=\operatorname{FWT}(A)_0-\operatorname{FWT}(A_1)\\
&=\operatorname{FWT}(A)_0-\operatorname{FWT}(A)_1\\\\
A_1
&=\operatorname{IFWT}(\operatorname{FWT}(A_1))\\
&=\operatorname{IFWT}(\operatorname{FWT}(A)_1)\\\\
A_0
&=\operatorname{IFWT}(\operatorname{FWT}(A_0))\\
&=\operatorname{IFWT}(\operatorname{FWT}(A)_0-\operatorname{FWT}(A)_1)\\\\
\end{aligned}
$$

### Code

```cpp
void FWT_AND(int *A)
{
    for (int i = 1; i < length; i <<= 1)
    {
        for (int j = 0; j < length; j += (i << 1))
        {
            for (int k = j; k < j + i; k++)
            {
                A[k + i] = A[k + i];
                A[k] = A[k] + A[k + i];
            }
        }
    }
}
void IFWT_AND(int *A)
{
    for (int i = 1; i < length; i <<= 1)
    {
        for (int j = 0; j < length; j += (i << 1))
        {
            for (int k = j; k < j + i; k++)
            {
                A[k + i] = A[k + i];
                A[k] = A[k] - A[k + i];
            }
        }
    }
}
```

直接写成一个函数：

```cpp
void FWT_AND(int *A, int opt) /*opt={-1,+1}*/
{
    for (int i = 1; i < length; i <<= 1)
    {
        for (int j = 0; j < length; j += (i << 1))
        {
            for (int k = j; k < j + i; k++)
            {
                A[k] = A[k] + opt * A[k + i];
            }
        }
    }
}
```

## 异或运算

PS：网络上都说前两个基本没用，异或考的最多。

### 卷积公式

$$
F(x)=\displaystyle\sum_{(i \text{ xor }j)=x}A(i)*B(j)
$$

### 正变换

定义多项式 $F$ 的异或运算的**沃尔什正变换**为：

$$
\begin{aligned}
\operatorname{FWT}(F)_i&
=\displaystyle\sum_{j=0}^{n} F_j[(i\text{ xor }j)=i]\\
&=\displaystyle\sum_{j=0}^{n} (-1)^{\operatorname{popcount}(i\text{ and } j)}F_j
\end{aligned}
$$

第 (2) 个式子我还真不会证明。

转移更新的式子：

$$
\operatorname{FWT}(F)=\operatorname{replace}(\operatorname{FWT}(F_0+F_1),\operatorname{FWT}(F_0-F_1))
$$

### 卷积

卷积时间复杂度 $O(n)$，处理完了 $\operatorname{FWT}A,\operatorname{FWT}B$。现在要证明：

$$
\operatorname{FWT}(A)*\operatorname{FWT}(B)=\operatorname{FWT}(F)
$$

还是证明任意一项，但是首先需要一个定理：

$$
(\operatorname{popcount}(i\text{ and }k)\text{ and }1)\text{ xor }(\operatorname{popcount}(j\text{ and }k)\text{ and }1)=\operatorname{popcount}((i\text{ xor }j)\text{ and }k)\text{ and }1
$$

用文字表达这个式子就是：$k$ **按位与** $i,j$ **按位异或**的值的**奇偶性**与 $k$ 分别**按位与** $i,j$ 的值的**按位异或**的值的**奇偶性**相同。

$$
\begin{aligned}
\operatorname{FWT} (F)_k
&=\displaystyle\sum_{s=0}^{n} (-1)^{\operatorname{popcount}(k\text{ and } s)}F_s\\
&=\displaystyle\sum_{s=0}^{n} (-1)^{\operatorname{popcount}(k\text{ and } s)}\displaystyle\sum_{(i\text{ xor }j)=s}^{n}A_i\times B_j\\
&=\displaystyle\sum_{i=0}^{n}\displaystyle\sum_{j=0}^{n} (-1)^{\operatorname{popcount}(k\text{ and } (i\text{ xor }j))}A_i\times B_j\\
&=\displaystyle\sum_{i=0}^{n}\displaystyle\sum_{j=0}^{n} (-1)^{(\operatorname{popcount}(k\text{ and } i))\text{ xor }(\operatorname{popcount}(k\text{ and } j))}A_i\times B_j\\
\end{aligned}
$$

发现 $(-1)^k$ 的取值只与指数 $k$ 的奇偶性有关。又因为异或的话：

奇数异或奇数结果：偶数。

偶数异或偶数结果：偶数。

偶数异或奇数结果：奇数。

奇数异或偶数结果：奇数。

所以原式中作为 $-1$ 指数的 $\operatorname{popcount}(k\text{ and } i)\text{ xor }\operatorname{popcount}(k\text{ and } j)$ 与 $(\operatorname{popcount}(i\text{ and }k)\text{ and }1)\text{ xor }(\operatorname{popcount}(j\text{ and }k)\text{ and }1)$ 是等价的。

此时这个式子只有四种情况，又发现：

$$
\begin{aligned}
(-1)^{1 \text{ xor } 1}&=(-1)^0=(-1)^{1+1}=(-1)^2=1\\
(-1)^{1 \text{ xor } 0}&=(-1)^1=(-1)^{1+0}=(-1)^1=-1\\
(-1)^{0 \text{ xor } 1}&=(-1)^1=(-1)^{0+1}=(-1)^1=-1\\
(-1)^{0 \text{ xor } 0}&=(-1)^0=(-1)^{0+0}=(-1)^0=1\\
\end{aligned}
$$

发现 $(\operatorname{popcount}(i\text{ and }k)\text{ and }1)\text{ xor }(\operatorname{popcount}(j\text{ and }k)\text{ and }1)$ 与 $(\operatorname{popcount}(i\text{ and }k)\text{ and }1)+(\operatorname{popcount}(j\text{ and }k)\text{ and }1)$ 也是等价的。替换之后，此时我们继续推式子：

$$
\begin{aligned}
\operatorname{FWT} (F)_k
&=\displaystyle\sum_{i=0}^{n}\displaystyle\sum_{j=0}^{n} (-1)^{(\operatorname{popcount}(k\text{ and } i))\text{ xor }(\operatorname{popcount}(k\text{ and } j))}A_i\times B_j\\
&=\displaystyle\sum_{i=0}^{n}\displaystyle\sum_{j=0}^{n} (-1)^{(\operatorname{popcount}(i\text{ and }k)\text{ and }1)+(\operatorname{popcount}(j\text{ and }k)\text{ and }1)}A(i)\times B(j)\\
&=\displaystyle\sum_{i=0}^{n}(-1)^{\operatorname{popcount}(i\text{ and }k)\text{ and }1}A(i)\times \displaystyle\sum_{j=0}^{n} (-1)^{\operatorname{popcount}(j\text{ and }k)\text{ and }1}B(j)\\
&=\displaystyle\sum_{i=0}^{n}(-1)^{\operatorname{popcount}(i\text{ and }k)}A(i)\times\displaystyle\sum_{j=0}^{n} (-1)^{\operatorname{popcount}(j\text{ and }k)}B(j)\\
&=\operatorname{FWT} (A)_k*\operatorname{FWT} (B)_k
\end{aligned}
$$

### 逆变换

多项式 $F$ 的**沃尔什逆变换**为点值变换为系数。

似乎不太能感性理解。

$$
\operatorname{IFWT}(F)=\operatorname{replace}(\operatorname{IFWT}(\frac{F_0+F_1}{2}),\operatorname{IFWT}(\frac{F_0-F_1}{2}))
$$

证明：

$$
\begin{aligned}
\operatorname{FWT}(A)_0
&=\operatorname{FWT}(A_0)+\operatorname{FWT}(A_1)\\
\operatorname{FWT}(A_0)
&=\operatorname{FWT}(A)_0-\operatorname{FWT}(A_1)\\\\
\operatorname{FWT}(A)_1
&=\operatorname{FWT}(A_0)-\operatorname{FWT}(A_1)\\
\operatorname{FWT}(A_1)
&=\operatorname{FWT}(A_0)-\operatorname{FWT}(A)_1\\\\
\operatorname{FWT}(A_0)
&=\operatorname{FWT}(A)_0-\operatorname{FWT}(A_0)+\operatorname{FWT}(A)_1\\
&=\frac{\operatorname{FWT}(A)_0+\operatorname{FWT}(A)_1}{2}\\\\
\operatorname{FWT}(A_1)
&=\operatorname{FWT}(A)_0-\operatorname{FWT}(A_1)-\operatorname{FWT}(A)_1\\
&=\frac{\operatorname{FWT}(A)_0-\operatorname{FWT}(A)_1}{2}\\\\
A_0
&=\operatorname{IFWT}(\operatorname{FWT}(A_0))\\
&=\operatorname{IFWT}(\frac{\operatorname{FWT}(A)_0+\operatorname{FWT}(A)_1}{2})\\\\
A_1
&=\operatorname{IFWT}(\operatorname{FWT}(A_1))\\
&=\operatorname{IFWT}(\frac{\operatorname{FWT}(A)_0-\operatorname{FWT}(A)_1}{2})\\\\
\end{aligned}
$$

### Code

```cpp
void FWT_XOR(int *A, int opt) /*opt={-1,+1}*/
{
    for (int i = 1; i < length; i <<= 1)
    {
        for (int j = 0; j < length; j += (i << 1))
        {
            for (int k = j; k < j + i; k++)
            {
                int x = A[k] / ((opt == -1) ? 2 : 1);
                int y = A[k + i] / ((opt == -1) ? 2 : 1);
                A[k] = x + y;
                A[k + i] = x - y;
            }
        }
    }
}
```

## Summary

索性觉得结论才是重点

### 卷积

$$
\begin{aligned}
\text{or}&:F_x=\displaystyle\sum_{(i \text{ or }j)=x}A_i\times B_j\\
\text{and}&:F_x=\displaystyle\sum_{(i \text{ and }j)=x}A_i\times B_j\\
\text{xor}&:F_x=\displaystyle\sum_{(i \text{ xor }j)=x}A_i\times B_j\\
\end{aligned}
$$

### 正变换定义

$$
\begin{aligned}
\text{or}&:\operatorname{FWT}(F)
_i=\displaystyle\sum_{j\supset i}^{n} F_j\\
\text{and}&:\operatorname{FWT}(F)
_i=\displaystyle\sum_{i\supset j}^{n} F_j\\
\text{xor}&:\operatorname{FWT}(F)_i=\displaystyle\sum_{j=0}^{n} (-1)^{\operatorname{popcount}(i\text{ and } j)}F_j\\
\end{aligned}
$$

### 正变换

$$
\begin{aligned}
\text{or}&:\operatorname{FWT}(F)=\operatorname{replace}(\operatorname{FWT}(F_0),\operatorname{FWT}(F_0+F_1))\\
\text{and}&:\operatorname{FWT}(F)=\operatorname{replace}(\operatorname{FWT}(F_0+F_1),\operatorname{FWT}(F_1))\\
\text{xor}&:\operatorname{FWT}(F)=\operatorname{replace}(\operatorname{FWT}(F_0+F_1),\operatorname{FWT}(F_0-F_1))\\
\text{xnor}&:\operatorname{FWT}(F)=\operatorname{replace}(\operatorname{FWT}(F_1-F_0),\operatorname{FWT}(F_1+F_0))\\
\end{aligned}
$$

### 逆变换

$$
\begin{aligned}
\text{or}&:\operatorname{FWT}(F)=\operatorname{replace}(\operatorname{FWT}(F_0),\operatorname{FWT}(F_0-F_1))\\
\text{and}&:\operatorname{FWT}(F)=\operatorname{replace}(\operatorname{FWT}(F_0-F_1),\operatorname{FWT}(F_1))\\
\text{xor}&:\operatorname{FWT}(F)=\operatorname{replace}(\operatorname{FWT}(\frac{F_0+F_1}{2}),\operatorname{FWT}(\frac{F_0-F_1}{2}))\\
\text{xnor}&:\operatorname{FWT}(F)=\operatorname{replace}(\operatorname{FWT}(\frac{F_1-F_0}{2}),\operatorname{FWT}(\frac{F_1+F_0}{2}))\\
\end{aligned}
$$

### 模板

[链接](https://www.luogu.com.cn/problem/P4717 "链接")

```cpp
#include <bits/stdc++.h>
using namespace std;
#define ll long long
const int N = (1 << 17) + 5;
const int MOD = 998244353;
const int INV = 499122177;
int n, length;
void FWT(int *A, int opt, char c)
{
    for (int i = 1; i < length; i <<= 1)
        for (int j = 0; j < length; j += (i << 1))
            for (int k = j; k < i + j; k++)
            {
                ll x = A[k], y = A[k + i];
                switch (c)
                {
                case '|':
                    A[k] = x;
                    A[k + i] = (y + opt * x + MOD) % MOD;
                    break;
                case '&':
                    A[k] = (x + opt * y + MOD) % MOD;
                    A[k + i] = y;
                    break;
                case '^':
                    A[k] = (x + y + MOD) % MOD * (opt == 1 ? 1 : INV) % MOD;
                    A[k + i] = (x - y + MOD) % MOD * (opt == 1 ? 1 : INV) % MOD;
                    break;
                }
            }
}
int A[N], B[N], C[N], F[N], G[N];
void solve(char c)
{
    memcpy(F, A, sizeof(F));
    memcpy(G, B, sizeof(G));
    FWT(F, 1, c);
    FWT(G, 1, c);
    for (int i = 0; i < length; i++)
        C[i] = 1ll * F[i] * G[i] % MOD;
    FWT(C, -1, c);
    for (int i = 0; i < length; i++)
        printf("%d ", C[i]);
    putchar('\n');
}
signed main()
{
    cin >> n;
    length = 1 << n;
    for (int i = 0; i < length; i++)
        cin >> A[i];
    for (int i = 0; i < length; i++)
        cin >> B[i];
    solve('|');
    solve('&');
    solve('^');
    return 0;
}
```