Update：2022-08-23 21:47:19 更新了语法。

---

## 线性筛积性函数

1. Euler筛 $\varphi$

    $$
    \begin{cases}
    i=1&\varphi(i)=1\\
    i\in prime
    &\varphi(i)=i-1\\
    i\notin prime\land prime\mid i
    &\varphi(i*prime)=\varphi(i)\times prime\\
    i\notin prime\land prime\nmid i
    &\varphi(i*prime)=\varphi(i)\times \varphi(prime)=\varphi(i)\times (prime-1)\\
    \end{cases}
    $$

    Code

    ```cpp
    void get_phi(int n)
    {
        vis[1] = 1;
        phi[1] = 1;
        for (int i = 2; i <= n; i++)
        {
            if (!vis[i])
            {
                prime[++cnt] = i;
                phi[i] = i - 1;
            }
            for (int j = 1; j <= cnt && i * prime[j] <= n; j++)
            {
                vis[i * prime[j]] = true;
                if (i % prime[j] == 0)
                {
                    phi[i * prime[j]] = phi[i] * prime[j];
                    break;
                }
                phi[i * prime[j]] = phi[i] * phi[prime[j]];
            }
        }
    }
    ```

2. Euler筛 $\mu$

    $$
    \begin{cases}
    i=1&\mu(i)=1\\
    i\in prime
    &\mu(i)=-1\\
    i\notin prime\land prime\mid i
    &\mu(i*prime)=0\\
    i\notin prime\land prime\nmid i
    &\mu(i*prime)=\mu(i)\times \mu(prime)=-\mu(i)\\
    \end{cases}
    $$

    Code

    ```cpp
    void get_mu(int n)
    {
        vis[1] = 1;
        mu[1] = 1;
        for (int i = 2; i <= n; i++)
        {
            if (!vis[i])
            {
                prime[++cnt] = i;
                mu[i] = -1;
            }
            for (int j = 1; j <= cnt && i * prime[j] <= n; j++)
            {
                vis[i * prime[j]] = true;
                if (i % prime[j] == 0)
                {
                    mu[i * prime[j]] = 0;
                    break;
                }
                mu[i * prime[j]] = -mu[i];
            }
        }
    }
    ```

## 原根

1. 阶

    $(1)$.定义:

    满足同余式 $a^n\equiv1(\bmod\,m)$ 的最小正整数 $n$ 存在，这个 $n$ 称作 $a\bmod m$ 的**阶**，记做 $\delta_m(a)$。

    $(2)$.性质：

    i. $a,a^2,a^3,...a^{\delta_m(a)}$ 模 $m$ 两两不同余。

    ii.若 $a^n\equiv1(\bmod\,m)$，则 ${\delta_m(a)}\mid n$。

2. 原根

    $(1)$.定义：

    满足 $\gcd(a,m)=1\land\delta_m(a)=\varphi(m)$，其中 $m\in N^*,a\in Z$，则称 $a$ 为模 $m$ 的**原根**。

    $(2)$.原根判定

     $m\geqslant3,\gcd(a,m)=1$，对于 $\varphi(m)$ 的每个质因子 $p$，都有 $a^{\frac{\varphi(m)}{p}}\not\equiv1(\bmod\,m)$。

    关于判定**直接暴力**：

    王元于 1959 年证明了若有原根，其最小原根是不多于 $m^{0.25}$ 级别的。此处略去证明。

    这保证了我们暴力找一个数的最小原根，复杂度是可以接受的。--oi wiki

    $(3)$.原根个数

    若 $m$ 有原根，则原根个数为 $\varphi(\varphi(m))$。

    $(4)$.原根存在判定

    **这是 (3) 原根个数的使用前提！！！**

    对于 $m$ 存在原根当且仅当

    $$
    m=\{2\lor4\lor p^a\lor2\times p^a\qquad p\in prime\land p>2\}
    $$

    本人太菜，无证明：click [here](https://oi-wiki.org/math/number-theory/primitive-root/) to get more information.

## 二元一次不定方程（EXGCD）

1. 对于 $ax+by=\gcd(a,b)$，那这只是对于最普通的方程，我们考虑对于 $ax+by=c$ 求解，我们暂且叫她**拓展线性方程**（~~我瞎起的~~）。对于 $ax\equiv c(\bmod\,b)$ 同理。

    **无解情况**：

    $$
    c\nmid \gcd(a,b)
    $$

    **有解情况**：

    我们可以先求出 $ax+by=\gcd(a,b)$ 的特解。再将 $x_0,y_0$ 都乘上 $\frac{c}{\gcd(a,b)}$。就得到了 $ax+by=c$ 的解了。

    通解

    $$
    \begin{cases}
    x=x_0\times\frac{c}{\gcd(a,b)}+k\frac{b}{\gcd(a,b)}\\
    y=y_0\times\frac{c}{\gcd(a,b)}-k\frac{a}{\gcd(a,b)}\\
    \end{cases}
    $$

    为什么 $\frac{?}{\gcd(a,b)}$ 这一项不同时扩倍呢？因为可以先乘后将 $d$ 代入可得 $a(x-bd)+b(y+bd)=c$。如果扩倍了，那么 $d$ 就不是最小值了，通解会少。

4. [【模板】二元一次不定方程](https://www.luogu.com.cn/problem/P5656)

## 拓展中国剩余定理(EXCRT)

普通中国剩余定理有局限性，对于模数不互质的便无法处理，于是便有了拓展中国剩余定理(EXCRT)。

1. 算法流程

    拓展中国剩余定理是基于拓展欧几里得算法(EXGCD)的，需要用拓展欧几里得算法解线性方程。

    同样对于这组同余方程，但不保证模数两两互质。

    $$
    \begin{cases}
    x&\equiv r_1(\bmod\,m_1)\\
    x&\equiv r_2(\bmod\,m_2)\\
    &\vdots\\
    x&\equiv r_n(\bmod\,m_n)\\
    \end{cases}
    $$

    我们可以挑出两个式子（不保证 $\gcd(m_1,m_2)=1$）

    $$
    \begin{cases}
    x&\equiv r_1(\bmod\,m_1)\\
    x&\equiv r_2(\bmod\,m_2)\\
    \end{cases}
    $$

    考虑如何将这两个式子合并成一个。

    推式子：

    设

    $$
    x=k_1m_1+r_1=k_2m_2+r_2
    \qquad
    k_1,k_2\in Z
    $$

    移项得

    $$
    k_1m_1-k_2m_2=r_2-r_1
    $$

    注意 $r_2-r_1$ 可能不等于 $\gcd(m_1,m_2)$，因此首先判断有无解，**无解情况**即 $(r_2-r_1)\nmid \gcd(m_1,m_2)$，否则有解，再进行**拓展线性方程**，假设( $\Large sto 您 orz$ )已经用 exgcd 求解出 $k_1=k_0$。

    将 $k_0$ 代入可得

    $$
    x=k_0m_1+r_1
    \qquad
    (\bmod\,\operatorname{lcm}(m_1,m_2))
    $$

    成功了!

    -- @zh_dou

2. Code

    ```cpp
    #include <bits/stdc++.h>
    #define ll long long
    using namespace std;
    struct type
    {
        ll m;
        ll r;
    };
    type x, y;
    ll exgcd(ll a, ll b, ll &x, ll &y)
    {
        if (b == 0)
        {
            x = 1;
            y = 0;
            return a;
        }
        ll gcd = exgcd(b, a % b, y, x);
        y -= (a / b) * x;
        return gcd;
    }
    type excrt(type a, type b)
    {
        ll x, y;
        ll gcd = exgcd(a.m, b.m, x, y);
        ll lcm = (a.m * b.m) / gcd;
        ll mul = (b.r - a.r) / gcd;
        return (type){lcm, (x * mul * a.m + a.r) % lcm};
    }
    int main()
    {
        int n;
        scanf("%d", &n);
        for (int i = 1; i <= n; i++)
        {
            scanf("%lld%lld", &y.m, &y.r);
            if (i > 1)
                x = excrt(x, y);
            else
                x = y;
        }
        printf("%lld", x.r);
        return 0;
    }
    ```

3. [【模板】扩展中国剩余定理（EXCRT）](https://www.luogu.com.cn/problem/P4777)

**友情提示**：模板 excrt 数据过强，以上代码仅提供思路，仅供参考，对于较大数据如果取模不当会炸 long long，记得取模、**龟速乘**，我太弱了，用高精切掉的。

## 拓展卢卡斯定理(EXLucas)

1. 引入

    在解决问题时，会遇到模数不是质数的情况，便又有了拓展卢卡斯的定理(EXLucas)。（~~拓展卢卡斯和卢卡斯没关系~~）。

    仍然是这个问题，出题人又不保证 $p\in prime$。

    $$
    C_{n}^{m}\bmod p
    \qquad
    p\in N^*
    $$

2. 具体流程

    - **中国剩余定理**
    - **逆元**

    （可以看出 ExLucas 确实和 Lucas 一点关系没有。）

    $(1)$.对于模数 $P$ 根据**唯一分解定理**，我们可以把 $P$ 拆为几个质数相乘的形式。

    $$
    P=\displaystyle\prod_{i=1}^{n} p_i^{k_i}
    $$

    $(2)$.因为现在拆成的几个质数的乘积之间一定两两互质，根据**中国剩余定理**，可以列出下面的式子：

    $$
    \begin{cases}
    x&\equiv C_n^m(\bmod\,p_1^{k_1})\\
    x&\equiv C_n^m(\bmod\,p_2^{k_2})\\
    &\vdots\\
    x&\equiv C_n^m(\bmod\,p_n^{k_n})\\
    \end{cases}
    $$

    $(3)$.解出每一个方程。

    $(4)$.合并中国剩余定理。

3. 解释流程 (3)

    相信大家最疑惑的一定是 $(3)$ 吧，我们随便拎出来一个式子：

    $$
    C_n^m\bmod p^k=\frac{n!}{m!(n-m)!}\bmod p^k
    $$

    阶乘内可能含有 $p$，无法求逆元怎么解决呢？

    Answer :那就把 $p$ 提出来！

    举个很经典的**栗子**

    $22!,p=3,k=2,p^k=9$

    $$
    \begin{aligned}
    22!
    &\equiv(1\times 2\times 4\times 5\times 7\times 8)\\
    &\times (10\times 11\times 13\times 14\times 16\times 17)\\
    &\times (19\times 20\times 22)\\
    &\times (3\times 6\times 9\times 12\times 15\times 18\times 21)(\bmod\,3^2)\\
    &\equiv(1\times 2\times 4\times 5\times 7\times 8)^2\\
    &\times (19\times 20\times 22)\\
    &\times 3^7(1\times 2\times 3\times 4\times 5\times 6\times 7)(\bmod\,3^2)\\
    \end{aligned}
    $$

    我们可以发现这样一个规律：

    可以将式子拆为四部分

    - 提出来的 $p^x,x={\lfloor\frac{n}{p}\rfloor}$。

    - 含有质因子为 $p$ 的数每个都提出一个 $p$ 后变成了 ${\lfloor\frac{n}{p}\rfloor}!$。

    - 不含质因子但可以凑成以 $p^k$ 为单位的 ${\lfloor\frac{n}{p^k}\rfloor}$ 组数。

    - 剩下的数字。

    化成一个恶心的式子：

    $$
    \begin{aligned}
    n!={\lfloor\frac{n}{p}\rfloor}!\times p^{\lfloor\frac{n}{p}\rfloor}\times ({\displaystyle\prod_{i=1\land i\nmid p}^{p^k}i})^{\lfloor\frac{n}{p^k}\rfloor}\times ({\displaystyle\prod_{i=p^k\times {\lfloor\frac{n}{p^k}\rfloor}+1\land i\nmid p}^{n}i})
    \end{aligned}
    $$

    我们发现 ${\lfloor\frac{n}{p}\rfloor}!$ 可以继续**递归求解**。

    我们定义 $f(n)$ 为提完所有 $p$ 以后阶乘之和，定义函数 $g(n)$ 为从 $n!$ 提出来的 $p$ 的次幂。同样可以递归求解。

    $$
    f(x)={f(\lfloor\frac{n}{p}\rfloor})\times ({\displaystyle\prod_{i=1\land i\nmid p}^{p^k}i})^{\lfloor\frac{n}{p^k}\rfloor}\times ({\displaystyle\prod_{i=p^k\times {\lfloor\frac{n}{p^k}\rfloor}+1\land i\nmid p}^{n}i})
    $$

    $$
    g(n)=\lfloor\frac{n}{p}\rfloor+g(\lfloor\frac{n}{p}\rfloor)
    $$

    对每一个阶乘进行操作，就得到了这个式子：

    $$
    \frac{\frac{n!}{p^x}}{\frac{m!}{p^y}\times\frac{(n-m)!}{p^z}}\times p^{x-y-z}(\bmod\,p^k)
    $$

    $$
    \frac{f(n)}{f(m)f(n-m)}p^{g(n)-g(n-m)-g(m)}(\bmod\,p^k)
    $$

    此时我们发现：我们已经从所有阶乘中提尽了 $p$。

    $$
    \because
    \gcd(p^k,f(m))=1
    \land
    \gcd(p^k,f(n-m))=1
    $$

    $\therefore f(m),f(n-m)$ 存在模 $p^k$ 意义下的逆元。

    其中 $g(m)+g(n-m)\leqslant g(n)$ 一定成立。

    简单说明一下，已知 $n\gt m$，先将 $n!$ 的前 $m$ 项消掉，剩下 $n-m$ 项为 $n\times (n-1)\times ...\times (n-m+1)$，所以这剩下的 $n-m$ 项一定不小于 $(n-m)!$，因此 $g(m)+g(n-m)\leqslant g(n)$。

    已经解决了最困难的一步，中国剩余定理等一些简单的东西可以参考前文。

    成功了！

4. Code

    ```cpp
    #include <bits/stdc++.h>
    #define ll long long
    using namespace std;
    vector<int> prime;
    vector<bool> vis;
    void Euler(ll n)
    {
        vis.resize(n + 1);
        for (int i = 2; i <= n; i++)
        {
            if (!vis[i])
            {
                prime.push_back(i);
            }
            for (int j = 0; j < prime.size() && prime[j] * i <= n; j++)
            {
                vis[i * prime[j]] = true;
                if (i % prime[j] == 0)
                    break;
            }
        }
    }
    void exgcd(ll a, ll b, ll &x, ll &y)
    {
        if (b == 0)
        {
            x = 1;
            y = 0;
            return;
        }
        exgcd(b, a % b, y, x);
        y -= (a / b) * x;
    }
    ll quick_pow(ll x, ll y, ll mod)
    {
        ll ans = 1;
        while (y > 0)
        {
            if (y & 1)
                ans = ans * x % mod;
            x = x * x % mod;
            y >>= 1;
        }
        return ans % mod;
    }
    ll inv(ll m, ll mod)
    {
        ll x, y;
        exgcd(m, mod, x, y);
        return (x % mod + mod) % mod;
    }
    ll f(ll n, ll p, ll mod)
    {
        if (n == 0)
            return 1;
        ll A = 1;
        ll B = 1;
        for (int i = 1; i <= mod; i++)
            if (i % p != 0)
                A = A * i % mod;
        A = quick_pow(A, n / mod, mod);
        for (int i = 1; i <= n % mod; i++)
            if (i % p != 0)
                B = B * i % mod;
        return f(n / p, p, mod) % mod * A % mod * B % mod;
    }
    ll g(ll n, ll p)
    {
        if (n < p)
            return 0;
        return n / p + g(n / p, p);
    }
    ll get_rest(ll n, ll m, ll p, ll mod)
    {
        return f(n, p, mod) % mod * inv(f(m, p, mod), mod) % mod * inv(f(n - m, p, mod), mod) % mod *
            quick_pow(p, g(n, p) - g(m, p) - g(n - m, p), mod) % mod;
    }
    ll crt(vector<ll> m, vector<ll> r, ll M, int n)
    {
        ll ans = 0;
        for (int i = 1; i <= n; i++)
            ans = (ans + r[i] % M * inv(M / m[i], m[i]) % M * (M / m[i]) % M) % M;
        return ans;
    }
    ll exlucas(ll n, ll m, ll p)
    {
        ll M = p;
        vector<ll> mod;
        vector<ll> rest;
        mod.push_back(0);
        rest.push_back(0);
        for (int i = 0; p > 0 && i < prime.size(); i++)
        {
            if (p % prime[i] == 0)
            {
                mod.push_back(1);
                rest.push_back(0);
                int x = mod.size() - 1;
                while (p % prime[i] == 0)
                {
                    p /= prime[i];
                    mod[x] *= prime[i];
                }
                rest[x] = get_rest(n, m, prime[i], mod[x]);
            }
        }
        return crt(mod, rest, M, mod.size() - 1);
    }
    int main()
    {
        ll n, m, p;
        scanf("%lld%lld%lld", &n, &m, &p);
        Euler(p);
        printf("%lld", exlucas(n, m, p));
        return 0;
    }
    ```

5. [【模板】扩展卢卡斯定理（EXLucas）](https://www.luogu.com.cn/problem/P4720)

## 拓展 BSGS(EXBSGS)

基本上模质数的算法都会有拓展（EX），BSGS 也不例外，对于以上问题若不保证模数为质数，便需要新的算法。

1. 引入

    给定一个令人开心的式子：

    $$
    a^x\equiv b
    \qquad
    (\bmod\,p)
    \qquad
    p\in N^*
    $$

2. 具体流程

    $(1)$.老套路，既然不互质，就模到互质为止，具体如下：

    我们先同时除以出来一个 $\gcd(a,p)$。

    $$
    a^{x-1}\times\frac{a}{\gcd(a,p)}\equiv \frac{b}{\gcd(a,p)}
    \qquad
    (\bmod\,\frac{p}{\gcd(a,p)})
    $$

    继续除，直到 $a,p$ 互质。

    再说明**无解条件**：再除的过程中出现 $b\nmid \gcd(a,p)$，那方程无解。

    $(2)$.假设除了 $k$ 次后，$\gcd(a,p)=1$。得到了这个式子：

    $$
    a^{x-k}\times\frac{a^k}{\prod \gcd(a,p)}\equiv \frac{b}{\prod \gcd(a,p)}
    \qquad
    (\bmod\,\frac{p}{\prod \gcd(a,p)})
    $$

    $(3)$.此时 $\gcd(a,p)=1\land \gcd(\frac{a^k}{\prod \gcd(a,p)},p)=1$，符合逆元的条件，于是就可以把 $\frac{a^k}{\prod \gcd(a,p)}$ 移过去，太巨了，$\Large sto 您 orz$ 又可以套 BSGS 板子**暴切** EXBSGS 了。

3. Code

    ```cpp
    #include <bits/stdc++.h>
    #define ll long long
    using namespace std;
    ll gcd(ll a, ll b)
    {
        return (b == 0) ? a : gcd(b, a % b);
    }
    ll quick_pow(ll x, ll y, ll mod)
    {
        ll ans = 1;
        while (y > 0)
        {
            if (y & 1 == 1)
                ans = ans * x % mod;
            x = x * x % mod;
            y >>= 1;
        }
        return ans % mod;
    }
    void exgcd(ll a, ll b, ll &x, ll &y)
    {
        if (b == 0)
        {
            x = 1;
            y = 0;
            return;
        }
        exgcd(b, a % b, y, x);
        y -= (a / b) * x;
    }
    ll inv(ll m, ll mod)
    {
        ll x, y;
        exgcd(m, mod, x, y);
        return (x % mod + mod) % mod;
    }
    ll BSGS(ll a, ll b, ll p)
    {
        map<ll, vector<int>> s;
        a %= p;
        b %= p;
        if (b == 0)
            b += p;
        ll sqr = ceil(sqrt(p));
        for (int i = 0; i <= sqr; i++, b = b * a % p)
            s[b].push_back(i);
        ll k = quick_pow(a, sqr, p);
        ll mul = 1 % p;
        for (int i = 0; i <= sqr; i++, mul = mul * k % p)
            if (s.count(mul))
                for (int j = s[mul].size() - 1; j >= 0; j--)
                    if (sqr * i - s[mul][j] >= 0)
                        return sqr * i - s[mul][j];
        return -1;
    }
    ll EXBSGS(ll a, ll b, ll p)
    {
        a %= p;
        b %= p;
        if (b == 0)
            b += p;
        ll g = gcd(a, p);
        ll add = 1;
        ll k = 0;
        while (g > 1)
        {
            if (b == add)
                return k;
            if (b % g != 0)
                return -1;
            ++k;
            p /= g;
            b /= g;
            add = add * (a / g) % p;
            g = gcd(a, p);
        }
        ll ans = BSGS(a, b * inv(add, p), p);
        return ans == -1 ? -1 : k + ans;
    }
    int main()
    {
        ll p, a, b;
        scanf("%lld%lld%lld", &p, &a, &b);
        printf("%lld", EXBSGS(a, b, p));
        return 0;
    }
    ```

4. [【模板】扩展 BSGS](https://www.luogu.com.cn/problem/P4195)

    **友情提醒**：本题**卡常**，加些快读或手写 HASH，能不能 Accepted 看造化了。

    **其他细节**：

    - 在让 $a,p$ 互质的过程中要特判 $b=\frac{a^k}{\prod \gcd(a,p)}$，若相等，将 $\frac{a^k}{\prod \gcd(a,p)}$ 移过去消掉，得到 $a^{x-k}\equiv 1(\bmod\,p^{'})$，即 $x=k$，直接返回 $k$ 即可。

    - 有解时记得将除掉的 $k$ 次幂加上。